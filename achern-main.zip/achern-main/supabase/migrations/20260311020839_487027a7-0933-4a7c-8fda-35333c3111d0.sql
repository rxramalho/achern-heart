-- Create table to persist monthly routing data
CREATE TABLE public.routing_data (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  month_key TEXT NOT NULL UNIQUE,
  data JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.routing_data ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read" ON public.routing_data FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON public.routing_data FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON public.routing_data FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON public.routing_data FOR DELETE USING (true);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_routing_data_updated_at
  BEFORE UPDATE ON public.routing_data
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();