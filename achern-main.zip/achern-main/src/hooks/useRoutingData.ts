import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";

interface RoutingSlot {
  crm: string;
  doctorName: string;
  productFocus: string;
}

type DayFlag = "" | "feriado" | "ponte" | "folga" | "reuniao";

interface MonthRoutingData {
  version: number;
  days: Record<string, RoutingSlot[]>;
  flags: Record<string, DayFlag>;
}

const EMPTY_DATA: MonthRoutingData = { version: 1, days: {}, flags: {} };

function getMonthKey(year: number, month: number): string {
  return `standard_routing_${year}-${String(month + 1).padStart(2, "0")}`;
}

function sanitize(parsed: any): MonthRoutingData {
  if (!parsed || typeof parsed !== "object" || !parsed.days) return { ...EMPTY_DATA };
  const sanitized: Record<string, RoutingSlot[]> = {};
  for (const [key, value] of Object.entries(parsed.days as Record<string, unknown>)) {
    if (!Array.isArray(value)) { sanitized[key] = []; continue; }
    sanitized[key] = value
      .map((s: any) => ({
        crm: String(s?.crm ?? ""),
        doctorName: String(s?.doctorName ?? ""),
        productFocus: String(s?.productFocus ?? ""),
      }))
      .filter((s) => s.crm.trim().length > 0);
  }
  const validFlags = new Set(["", "feriado", "ponte", "folga", "reuniao"]);
  const flags: Record<string, DayFlag> = {};
  if (parsed.flags && typeof parsed.flags === "object") {
    for (const [key, val] of Object.entries(parsed.flags as Record<string, unknown>)) {
      const v = String(val || "");
      if (validFlags.has(v)) flags[key] = v as DayFlag;
    }
  }
  return { version: Number(parsed.version) || 1, days: sanitized, flags };
}

export function useRoutingData(year: number, month: number) {
  const [data, setData] = useState<MonthRoutingData>({ ...EMPTY_DATA });
  const [loading, setLoading] = useState(true);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const latestData = useRef<MonthRoutingData>(data);

  // Keep ref in sync
  useEffect(() => { latestData.current = data; }, [data]);

  // Load from DB (with localStorage fallback for migration)
  useEffect(() => {
    let cancelled = false;
    const key = getMonthKey(year, month);

    async function load() {
      setLoading(true);
      try {
        const { data: row } = await supabase
          .from("routing_data")
          .select("data")
          .eq("month_key", key)
          .maybeSingle();

        if (cancelled) return;

        if (row?.data) {
          setData(sanitize(row.data));
        } else {
          // Migrate from localStorage if exists
          const localRaw = localStorage.getItem(key);
          if (localRaw) {
            const parsed = sanitize(JSON.parse(localRaw));
            setData(parsed);
            // Save to DB immediately
            await supabase.from("routing_data").upsert(
              { month_key: key, data: parsed as any },
              { onConflict: "month_key" }
            );
          } else {
            setData({ ...EMPTY_DATA });
          }
        }
      } catch {
        // Fallback to localStorage
        try {
          const localRaw = localStorage.getItem(key);
          if (localRaw && !cancelled) setData(sanitize(JSON.parse(localRaw)));
        } catch { /* ignore */ }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => { cancelled = true; };
  }, [year, month]);

  // Debounced save to DB + localStorage backup
  const persist = useCallback(() => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      const key = getMonthKey(year, month);
      const current = latestData.current;
      // localStorage backup
      try { localStorage.setItem(key, JSON.stringify(current)); } catch { /* */ }
      // DB save
      supabase.from("routing_data").upsert(
        { month_key: key, data: current as any },
        { onConflict: "month_key" }
      ).then();
    }, 500);
  }, [year, month]);

  // Auto-persist on data changes
  useEffect(() => {
    if (!loading) persist();
  }, [data, loading, persist]);

  // Cleanup timer
  useEffect(() => () => { if (saveTimer.current) clearTimeout(saveTimer.current); }, []);

  return { data, setData, loading };
}
