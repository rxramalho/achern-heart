import { useState, useEffect } from "react";
import { Doctor, ApiResponse } from "@/types/doctor";
import { mockDoctors } from "@/data/mockDoctors";

const API_URL_KEY = "medical_panel_api_url";

export function useDoctors() {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [apiUrl, setApiUrl] = useState(() => localStorage.getItem(API_URL_KEY) || "");
  const [usingMock, setUsingMock] = useState(false);

  const saveApiUrl = (url: string) => {
    localStorage.setItem(API_URL_KEY, url);
    setApiUrl(url);
  };

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      setError(null);

      if (!apiUrl) {
        setDoctors(mockDoctors);
        setUsingMock(true);
        setLoading(false);
        return;
      }

      try {
        const noCacheUrl = `${apiUrl}${apiUrl.includes("?") ? "&" : "?"}_ts=${Date.now()}`;
        const response = await fetch(noCacheUrl, { method: "GET", cache: "no-store" });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const text = await response.text();
        if (text.trimStart().startsWith("<")) {
          throw new Error("A URL da API retornou HTML em vez de JSON. Verifique se o deploy do Apps Script está como 'Anyone' e re-deploy.");
        }
        
        const data: ApiResponse = JSON.parse(text);
        if (data.error) throw new Error(data.error);
        
        setDoctors(data.doctors || []);
        setUsingMock(false);
      } catch (err) {
        console.error("Erro ao buscar dados:", err);
        setError(err instanceof Error ? err.message : "Erro desconhecido");
        setDoctors(mockDoctors);
        setUsingMock(true);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [apiUrl]);

  return { doctors, loading, error, apiUrl, saveApiUrl, usingMock };
}
