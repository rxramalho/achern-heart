export interface MarketData {
  semPrescricao: number;
  cat1: number;
  cat2: number;
  cat3: number;
  cat4: number;
  cat5: number;
}

export interface Doctor {
  crmPainel: string;
  ufCrm: string;
  checkVisitar: string;
  falar: string; // "V" = visitar, "NV" = não visitar
  visitadoCiclo: number | string; // Coluna E COMPILADO: dias desde a última visita
  medico: string;
  cat: string;
  deltaMedico: string;
  especialidade: string;
  clinica: string;
  scoreClinica: number;
  scoreEspecialidade: number;
  endereco: string;
  cidade: string;
  mercados: Record<string, MarketData>;
  disponibilidade: string;
  horarios?: boolean[]; // 10 booleans: [SegM, SegT, TerM, TerT, QuaM, QuaT, QuiM, QuiT, SexM, SexT]
}

// Verifica se o médico já foi visitado no ciclo atual
export function wasVisitedInCycle(doctor: Doctor, currentCycleDay: number): boolean {
  const visitDay = typeof doctor.visitadoCiclo === 'string' 
    ? parseInt(doctor.visitadoCiclo, 10) 
    : doctor.visitadoCiclo;
  
  if (isNaN(visitDay) || visitDay === 0) return false;
  return visitDay <= currentCycleDay;
}

// Verifica se deve visitar baseado na coluna "falar"
export function shouldVisit(doctor: Doctor): boolean {
  return doctor.falar?.toUpperCase() === "V";
}

// Calcula quantos dias úteis tem no mês atual (excluindo sab/dom)
export function getWorkingDaysInMonth(year: number, month: number): number {
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  let workingDays = 0;
  
  for (let day = 1; day <= daysInMonth; day++) {
    const dayOfWeek = new Date(year, month, day).getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) workingDays++;
  }
  
  return workingDays;
}

// Calcula o dia útil atual no ciclo (excluindo sab/dom)
export function getCurrentWorkingDay(): number {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();
  const currentDay = today.getDate();
  
  let workingDay = 0;
  for (let day = 1; day <= currentDay; day++) {
    const dayOfWeek = new Date(year, month, day).getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) workingDay++;
  }
  
  return workingDay;
}

export interface ApiResponse {
  totalDoctors: number;
  products: string[];
  lastUpdate: string;
  doctors: Doctor[];
  error?: string;
}

export const PRODUCTS = [
  "ALENIA", "BUSONID NASAL", "BIXLYN", "ARTROLIVE",
  "MOTORE", "LEUCOGEN", "MONTELAIR", "OSTEOBAN",
  "COMBTOL", "ANDRUM", "BUSONID ORAL", "LAXIME",
  "NISULID", "CLILON", "LUBRIS", "LUTEAL"
] as const;

export type DayOfWeek = "segunda" | "terca" | "quarta" | "quinta" | "sexta";

export const DAY_MAP: Record<string, DayOfWeek> = {
  "2": "segunda",
  "3": "terca",
  "4": "quarta",
  "5": "quinta",
  "6": "sexta",
};

export const DAY_LABELS: Record<DayOfWeek, string> = {
  segunda: "Segunda",
  terca: "Terça",
  quarta: "Quarta",
  quinta: "Quinta",
  sexta: "Sexta",
};

export function parseAvailability(raw: string): { day: DayOfWeek; period: string }[] {
  if (!raw) return [];
  
  const results: { day: DayOfWeek; period: string }[] = [];
  // Format: "2MT 3M 4T 5MT 6M" or "2M,3MT" etc.
  const parts = raw.trim().split(/[\s,;]+/);
  
  for (const part of parts) {
    if (!part) continue;
    const dayCode = part.charAt(0);
    const periodCode = part.substring(1).toUpperCase();
    
    const day = DAY_MAP[dayCode];
    if (!day) continue;
    
    let period = "";
    if (periodCode.includes("M") && periodCode.includes("T")) {
      period = "Manhã e Tarde";
    } else if (periodCode.includes("M")) {
      period = "Manhã";
    } else if (periodCode.includes("T")) {
      period = "Tarde";
    } else {
      period = "Integral";
    }
    
    results.push({ day, period });
  }
  
  return results;
}

export function getTotalPrescriptions(doctor: Doctor, market: string): number {
  const m = doctor.mercados?.[market];
  if (!m) return 0;
  return (m.cat1 || 0) + (m.cat2 || 0) + (m.cat3 || 0) + (m.cat4 || 0) + (m.cat5 || 0);
}

export function getCategory(doctor: Doctor, market: string): number | null {
  const m = doctor.mercados?.[market];
  if (!m) return null;
  if (m.cat1 > 0) return 1;
  if (m.cat2 > 0) return 2;
  if (m.cat3 > 0) return 3;
  if (m.cat4 > 0) return 4;
  if (m.cat5 > 0) return 5;
  return null;
}

export function getCategoryValue(doctor: Doctor, market: string): number {
  const m = doctor.mercados?.[market];
  if (!m) return 0;
  if (m.cat1 > 0) return m.cat1;
  if (m.cat2 > 0) return m.cat2;
  if (m.cat3 > 0) return m.cat3;
  if (m.cat4 > 0) return m.cat4;
  if (m.cat5 > 0) return m.cat5;
  return 0;
}
