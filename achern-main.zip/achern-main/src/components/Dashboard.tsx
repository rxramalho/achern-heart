import { useState, useMemo } from "react";
import { useDoctors } from "@/hooks/useDoctors";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Settings, Database, Wifi, WifiOff, CalendarDays, LayoutDashboard, ChevronDown, Filter, Clock } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { PRODUCTS } from "@/types/doctor";
import VisitationModule from "@/components/VisitationModule";
import DashboardPanel from "@/components/DashboardPanel";
import ScheduleModule from "@/components/ScheduleModule";
import ErrorBoundary from "@/components/ErrorBoundary";

export default function Dashboard() {
  const { doctors, loading, error, apiUrl, saveApiUrl, usingMock } = useDoctors();
  const [urlInput, setUrlInput] = useState(apiUrl);

  // Global filters for dashboard
  const [dashFilterMarkets, setDashFilterMarkets] = useState<string[]>([]);
  const [dashFilterSpecialties, setDashFilterSpecialties] = useState<string[]>([]);
  const [dashFilterCities, setDashFilterCities] = useState<string[]>([]);
  const [dashFilterClinics, setDashFilterClinics] = useState<string[]>([]);
  const [dashMinDays, setDashMinDays] = useState<string>("0");

  const specialties = useMemo(
    () => [...new Set(doctors.map((d) => d.especialidade).filter(Boolean))].sort(),
    [doctors]
  );
  const cities = useMemo(
    () => [...new Set(doctors.map((d) => d.cidade).filter(Boolean))].sort(),
    [doctors]
  );
  const clinicsList = useMemo(
    () => [...new Set(doctors.map((d) => d.clinica).filter(Boolean))].sort(),
    [doctors]
  );

  const toggleItem = (list: string[], item: string, setter: (v: string[]) => void) => {
    setter(list.includes(item) ? list.filter((x) => x !== item) : [...list, item]);
  };

  const multiLabel = (selected: string[], allLabel: string, max = 2) =>
    selected.length === 0
      ? allLabel
      : selected.length <= max
        ? selected.join(", ")
        : `${selected.length} selecionados`;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-muted-foreground">Carregando dados...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-foreground">Painel Médico</h1>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant={usingMock ? "secondary" : "default"} className="text-xs">
              {usingMock ? (
                <><WifiOff className="h-3 w-3 mr-1" /> Dados Demo</>
              ) : (
                <><Wifi className="h-3 w-3 mr-1" /> API Conectada</>
              )}
            </Badge>
            <Badge variant="outline" className="text-xs">
              <Database className="h-3 w-3 mr-1" /> {doctors.length} médicos
            </Badge>
          </div>
          {error && <p className="text-xs text-destructive mt-1">{error}</p>}
        </div>

        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="icon">
              <Settings className="h-4 w-4" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80" align="end">
            <div className="space-y-3">
              <Label className="text-sm font-medium">URL da API (Google Apps Script)</Label>
              <Input
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="https://script.google.com/macros/s/.../exec"
                className="text-xs"
              />
              <Button size="sm" className="w-full" onClick={() => saveApiUrl(urlInput)}>
                Salvar e Reconectar
              </Button>
            </div>
          </PopoverContent>
        </Popover>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="painel">
        <TabsList className="mb-4">
          <TabsTrigger value="painel" className="gap-1.5">
            <LayoutDashboard className="h-3.5 w-3.5" />
            Painel
          </TabsTrigger>
          <TabsTrigger value="roteiro" className="gap-1.5">
            <CalendarDays className="h-3.5 w-3.5" />
            Roteiro Semanal
          </TabsTrigger>
          <TabsTrigger value="horarios" className="gap-1.5">
            <Clock className="h-3.5 w-3.5" />
            Horários
          </TabsTrigger>
        </TabsList>

        <TabsContent value="painel">
          {/* Dashboard filters */}
          <Card className="mb-6">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base font-semibold">
                <Filter className="h-4 w-4 text-primary" />
                Filtros do Painel
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                {/* Products multi-select */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-[220px] justify-between font-normal">
                      <span className="truncate">{multiLabel(dashFilterMarkets, "Todos os produtos")}</span>
                      <ChevronDown className="h-4 w-4 opacity-70" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[260px] p-3" align="start">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Produtos</p>
                        <Button type="button" variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setDashFilterMarkets([])}>Limpar</Button>
                      </div>
                      <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                        {PRODUCTS.map((m) => (
                          <label key={m} className="flex items-center gap-2 cursor-pointer">
                            <Checkbox checked={dashFilterMarkets.includes(m)} onCheckedChange={() => toggleItem(dashFilterMarkets, m, setDashFilterMarkets)} />
                            <span className="text-sm">{m}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>

                {/* Specialties multi-select */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-[240px] justify-between font-normal">
                      <span className="truncate">{multiLabel(dashFilterSpecialties, "Todas as especialidades")}</span>
                      <ChevronDown className="h-4 w-4 opacity-70" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[280px] p-3" align="start">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Especialidades</p>
                        <Button type="button" variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setDashFilterSpecialties([])}>Limpar</Button>
                      </div>
                      <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                        {specialties.map((s) => (
                          <label key={s} className="flex items-center gap-2 cursor-pointer">
                            <Checkbox checked={dashFilterSpecialties.includes(s)} onCheckedChange={() => toggleItem(dashFilterSpecialties, s, setDashFilterSpecialties)} />
                            <span className="text-sm">{s}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>

                {/* Cities multi-select */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-[180px] justify-between font-normal">
                      <span className="truncate">{multiLabel(dashFilterCities, "Todas as cidades")}</span>
                      <ChevronDown className="h-4 w-4 opacity-70" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[240px] p-3" align="start">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Cidades</p>
                        <Button type="button" variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setDashFilterCities([])}>Limpar</Button>
                      </div>
                      <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                        {cities.map((c) => (
                          <label key={c} className="flex items-center gap-2 cursor-pointer">
                            <Checkbox checked={dashFilterCities.includes(c)} onCheckedChange={() => toggleItem(dashFilterCities, c, setDashFilterCities)} />
                            <span className="text-sm">{c}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>

                {/* Clinics multi-select */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-[200px] justify-between font-normal">
                      <span className="truncate">{multiLabel(dashFilterClinics, "Todas as clínicas")}</span>
                      <ChevronDown className="h-4 w-4 opacity-70" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[260px] p-3" align="start">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">Clínicas</p>
                        <Button type="button" variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setDashFilterClinics([])}>Limpar</Button>
                      </div>
                      <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                        {clinicsList.map((c) => (
                          <label key={c} className="flex items-center gap-2 cursor-pointer">
                            <Checkbox checked={dashFilterClinics.includes(c)} onCheckedChange={() => toggleItem(dashFilterClinics, c, setDashFilterClinics)} />
                            <span className="text-sm">{c}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>

                {/* Days since visit */}
                <Select value={dashMinDays} onValueChange={setDashMinDays}>
                  <SelectTrigger className="w-[190px]">
                    <SelectValue placeholder="Dias sem visita" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Qualquer tempo</SelectItem>
                    <SelectItem value="30">≥ 30 dias sem visita</SelectItem>
                    <SelectItem value="60">≥ 60 dias sem visita</SelectItem>
                    <SelectItem value="90">≥ 90 dias sem visita</SelectItem>
                    <SelectItem value="120">≥ 120 dias sem visita</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <DashboardPanel
            doctors={doctors}
            filterMarkets={dashFilterMarkets}
            filterSpecialties={dashFilterSpecialties}
            filterCities={dashFilterCities}
            filterClinics={dashFilterClinics}
            minDaysSinceVisit={parseInt(dashMinDays, 10) || 0}
          />
        </TabsContent>

        <TabsContent value="roteiro">
          <ErrorBoundary fallbackMessage="Erro ao carregar Roteiro Semanal">
            <VisitationModule doctors={doctors} />
          </ErrorBoundary>
        </TabsContent>

        <TabsContent value="horarios">
          <ErrorBoundary fallbackMessage="Erro ao carregar Horários">
            <ScheduleModule doctors={doctors} apiUrl={apiUrl} />
          </ErrorBoundary>
        </TabsContent>
      </Tabs>
    </div>
  );
}
