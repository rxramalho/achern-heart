import { useState, useMemo, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Doctor } from "@/types/doctor";
import { Search, Clock, Save, Loader2, CheckCircle2, XCircle, Building2 } from "lucide-react";
import { toast } from "sonner";

const DAYS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta"] as const;
const PERIODS = ["Manhã", "Tarde"] as const;
const DAY_CODES = ["2", "3", "4", "5", "6"];

function getIdx(dayIdx: number, periodIdx: number) {
  return dayIdx * 2 + periodIdx;
}

function buildScheduleFlag(schedule: boolean[]): string {
  const parts: string[] = [];
  for (let d = 0; d < 5; d++) {
    const m = schedule[d * 2];
    const t = schedule[d * 2 + 1];
    if (m && t) parts.push(`${DAY_CODES[d]}MT`);
    else if (m) parts.push(`${DAY_CODES[d]}M`);
    else if (t) parts.push(`${DAY_CODES[d]}T`);
  }
  return parts.join("-") || "";
}

function safeJsonParse<T = unknown>(text: string): T | null {
  try {
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}

function toBooleanSlot(value: unknown): boolean {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value === 1;
  if (typeof value === "string") {
    const normalized = value.trim().toUpperCase();
    return normalized === "TRUE" || normalized === "1" || normalized === "X" || normalized === "SIM";
  }
  return false;
}

function normalizeSchedule(input: unknown): boolean[] | null {
  if (!Array.isArray(input)) return null;
  const parsed = input.slice(0, 10).map(toBooleanSlot);
  while (parsed.length < 10) parsed.push(false);
  return parsed;
}

/** Parse disponibilidade string like "4MT, 6M" or "2MT 3M" into boolean[10] */
function parseDisponibilidade(disp: string): boolean[] {
  const result = Array(10).fill(false);
  if (!disp) return result;
  const tokens = disp.split(/[\s,;-]+/).filter(Boolean);
  for (const token of tokens) {
    const match = token.match(/^([2-6])(M?)(T?)$/i);
    if (!match) continue;
    const dayCode = match[1];
    const hasM = match[2].toUpperCase() === "M" || token.toUpperCase().includes("MT");
    const hasT = match[3].toUpperCase() === "T" || token.toUpperCase().includes("MT");
    const dayIdx = DAY_CODES.indexOf(dayCode);
    if (dayIdx < 0) continue;
    if (hasM) result[dayIdx * 2] = true;
    if (hasT) result[dayIdx * 2 + 1] = true;
  }
  return result;
}

function getEffectiveHorarios(doctor: Doctor): boolean[] {
  const normalized = normalizeSchedule(doctor.horarios);
  if (normalized && normalized.some(Boolean)) return normalized;

  const parsedDisponibilidade = parseDisponibilidade(doctor.disponibilidade || "");
  if (parsedDisponibilidade.some(Boolean)) return parsedDisponibilidade;

  return normalized ?? Array(10).fill(false);
}

function buildNoCacheUrl(url: string): string {
  const sep = url.includes("?") ? "&" : "?";
  return `${url}${sep}_ts=${Date.now()}`;
}

interface ScheduleModuleProps {
  doctors: Doctor[];
  apiUrl: string;
}

export default function ScheduleModule({ doctors, apiUrl }: ScheduleModuleProps) {
  const [nameFilter, setNameFilter] = useState("");
  const [clinicFilter, setClinicFilter] = useState("");
  const [cityFilter, setCityFilter] = useState("");
  const [selectedCrm, setSelectedCrm] = useState<string | null>(null);
  const [schedule, setSchedule] = useState<boolean[]>(Array(10).fill(false));
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [editClinic, setEditClinic] = useState("");
  const [clinicDirty, setClinicDirty] = useState(false);

  const clinics = useMemo(() => [...new Set(doctors.map(d => d.clinica).filter(Boolean))].sort(), [doctors]);
  const cities = useMemo(() => [...new Set(doctors.map(d => d.cidade).filter(Boolean))].sort(), [doctors]);

  const filtered = useMemo(() => {
    return doctors.filter(d => {
      if (nameFilter && !d.medico.toLowerCase().includes(nameFilter.toLowerCase())) return false;
      if (clinicFilter && d.clinica !== clinicFilter) return false;
      if (cityFilter && d.cidade !== cityFilter) return false;
      return true;
    });
  }, [doctors, nameFilter, clinicFilter, cityFilter]);

  // Group filtered doctors by clinic
  const groupedByClinic = useMemo(() => {
    const groups: Record<string, Doctor[]> = {};
    for (const d of filtered) {
      const key = d.clinica || "Sem clínica";
      if (!groups[key]) groups[key] = [];
      groups[key].push(d);
    }
    return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
  }, [filtered]);

  const selectedDoctor = useMemo(() => {
    if (!selectedCrm) return null;
    return doctors.find(d => d.crmPainel === selectedCrm) || null;
  }, [doctors, selectedCrm]);

  const selectDoctor = useCallback((doctor: Doctor) => {
    setSelectedCrm(doctor.crmPainel);
    const h = getEffectiveHorarios(doctor);
    setSchedule([...h]);
    setEditClinic(doctor.clinica || "");
    setDirty(false);
    setClinicDirty(false);
  }, []);

  const toggleSlot = useCallback((idx: number) => {
    setSchedule(prev => {
      const next = [...prev];
      next[idx] = !next[idx];
      return next;
    });
    setDirty(true);
  }, []);

  const uncheckAll = useCallback(() => {
    setSchedule(Array(10).fill(false));
    setDirty(true);
  }, []);

  const saveSchedule = useCallback(async () => {
    if (!selectedDoctor || !apiUrl) {
      toast.error("Configure a URL da API antes de salvar.");
      return;
    }

    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        action: "updateSchedule",
        crm: selectedDoctor.crmPainel,
        horarios: schedule,
      };

      if (clinicDirty && editClinic !== selectedDoctor.clinica) {
        payload.clinica = editClinic;
      }

      const params = new URLSearchParams({
        action: "updateSchedule",
        crm: String(payload.crm),
        horarios: JSON.stringify(payload.horarios),
      });
      if (payload.clinica !== undefined) {
        params.set("clinica", String(payload.clinica));
      }

      // Tentativa 1: GET (suporta deployments que aceitam update em doGet)
      let updatedByGet = false;
      const getResponse = await fetch(`${apiUrl}${apiUrl.includes("?") ? "&" : "?"}${params.toString()}`, {
        method: "GET",
        cache: "no-store",
      });
      const getText = await getResponse.text();

      if (!getResponse.ok) {
        throw new Error(`Erro HTTP ${getResponse.status} ao salvar.`);
      }

      const getJson = safeJsonParse<{ success?: boolean; error?: string }>(getText);
      if (getJson?.error) {
        throw new Error(getJson.error);
      }

      if (getJson?.success === true) {
        updatedByGet = true;
      }

      // Tentativa 2: fallback POST (suporta deployments antigos com update apenas no doPost)
      if (!updatedByGet) {
        await fetch(apiUrl, {
          method: "POST",
          mode: "no-cors",
          headers: {
            "Content-Type": "text/plain;charset=utf-8",
          },
          body: JSON.stringify(payload),
        });
      }

      // Confirmação real direto da planilha (evita falso positivo de "salvou")
      await new Promise(resolve => setTimeout(resolve, 500));
      const verifyResponse = await fetch(buildNoCacheUrl(apiUrl), { method: "GET", cache: "no-store" });
      if (!verifyResponse.ok) {
        throw new Error(`Erro HTTP ${verifyResponse.status} ao confirmar gravação.`);
      }

      const verifyText = await verifyResponse.text();
      const verifyJson = safeJsonParse<{ doctors?: Doctor[]; error?: string }>(verifyText);
      if (verifyJson?.error) {
        throw new Error(verifyJson.error);
      }
      if (!verifyJson || !Array.isArray(verifyJson.doctors)) {
        throw new Error("Resposta inválida ao confirmar dados da planilha.");
      }

      const persistedDoctor = verifyJson.doctors.find(d => String(d.crmPainel) === String(selectedDoctor.crmPainel));
      if (!persistedDoctor) {
        throw new Error("Médico não encontrado ao confirmar gravação.");
      }

      const persistedSchedule = getEffectiveHorarios(persistedDoctor);
      const scheduleMatches = persistedSchedule.every((value, idx) => value === Boolean(schedule[idx]));
      const clinicMatches = !clinicDirty || (persistedDoctor.clinica || "") === editClinic;

      if (!scheduleMatches || !clinicMatches) {
        throw new Error("Alteração não confirmada na planilha COMPILADO/COLAGEM.");
      }

      for (const doctor of doctors) {
        if (String(doctor.crmPainel) === String(selectedDoctor.crmPainel)) {
          doctor.horarios = [...persistedSchedule];
          doctor.disponibilidade = persistedDoctor.disponibilidade || doctor.disponibilidade;
          if (clinicDirty) {
            doctor.clinica = persistedDoctor.clinica || editClinic;
          }
        }
      }

      setSchedule([...persistedSchedule]);
      setEditClinic(persistedDoctor.clinica || editClinic);
      setDirty(false);
      setClinicDirty(false);
      toast.success("Dados salvos na planilha!");
    } catch (err) {
      console.error("Erro ao salvar:", err);
      toast.error(err instanceof Error ? err.message : "Erro ao salvar");
    } finally {
      setSaving(false);
    }
  }, [selectedDoctor, apiUrl, schedule, editClinic, clinicDirty, doctors]);

  const scheduleFlag = useMemo(() => buildScheduleFlag(schedule), [schedule]);
  const isDirtyAny = dirty || clinicDirty;

  return (
    <div className="space-y-4">
      {/* Filters */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base font-semibold">
            <Clock className="h-4 w-4 text-primary" />
            Horários dos Médicos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <div className="relative w-[260px]">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome do médico..."
                value={nameFilter}
                onChange={e => setNameFilter(e.target.value)}
                className="pl-8"
              />
            </div>
            <Select value={clinicFilter} onValueChange={v => setClinicFilter(v === "__all__" ? "" : v)}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Todas as clínicas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">Todas as clínicas</SelectItem>
                {clinics.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={cityFilter} onValueChange={v => setCityFilter(v === "__all__" ? "" : v)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Todas as cidades" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">Todas as cidades</SelectItem>
                {cities.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Doctor list grouped by clinic */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Médicos ({filtered.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-[500px] overflow-y-auto">
              {groupedByClinic.length === 0 ? (
                <p className="text-sm text-muted-foreground p-4">Nenhum médico encontrado.</p>
              ) : (
                groupedByClinic.map(([clinic, docs]) => (
                  <div key={clinic}>
                    <div className="flex items-center gap-1.5 px-4 py-1.5 bg-muted/50 border-b border-border/50 sticky top-0">
                      <Building2 className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide truncate">{clinic}</span>
                      <Badge variant="outline" className="text-[10px] ml-auto">{docs.length}</Badge>
                    </div>
                    {docs.map(d => {
                      const flag = buildScheduleFlag(getEffectiveHorarios(d));
                      return (
                        <button
                          key={d.crmPainel}
                          onClick={() => selectDoctor(d)}
                          className={`w-full text-left px-4 py-2.5 border-b border-border/50 hover:bg-accent/50 transition-colors ${
                            selectedCrm === d.crmPainel ? "bg-primary/10 border-l-2 border-l-primary" : ""
                          }`}
                        >
                          <p className="text-sm font-medium text-foreground truncate">
                            {d.medico}
                            {flag && (
                              <span className="ml-1.5 text-xs font-normal text-primary">{flag}</span>
                            )}
                          </p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs text-muted-foreground">{d.cidade}</span>
                            <span className="text-xs text-muted-foreground">•</span>
                            <span className="text-xs text-muted-foreground">{d.especialidade}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Schedule editor */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">
                {selectedDoctor ? (
                  <span className="text-foreground">
                    {selectedDoctor.medico}
                    {scheduleFlag && (
                      <span className="ml-2 text-xs font-normal text-primary">{scheduleFlag}</span>
                    )}
                  </span>
                ) : (
                  <span className="text-muted-foreground">Selecione um médico</span>
                )}
              </CardTitle>
              <div className="flex items-center gap-2">
                {selectedDoctor && !isDirtyAny && (
                  <>
                    <Badge variant="outline" className="text-xs gap-1">
                      <CheckCircle2 className="h-3 w-3" /> Salvo
                    </Badge>
                    <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1" onClick={uncheckAll}>
                      <XCircle className="h-3 w-3" /> Desmarcar todos
                    </Button>
                  </>
                )}
                {selectedDoctor && isDirtyAny && (
                  <>
                    <Button variant="ghost" size="sm" className="h-7 px-2 text-xs gap-1" onClick={uncheckAll}>
                      <XCircle className="h-3 w-3" /> Desmarcar todos
                    </Button>
                    <Button size="sm" onClick={saveSchedule} disabled={saving || !apiUrl}>
                      {saving ? (
                        <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Salvando...</>
                      ) : (
                        <><Save className="h-3.5 w-3.5" /> Salvar</>
                      )}
                    </Button>
                  </>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {!selectedDoctor ? (
              <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                <Clock className="h-10 w-10 mb-3 opacity-30" />
                <p className="text-sm">Selecione um médico para editar os horários</p>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Doctor name (read-only) */}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Nome do Médico</label>
                  <Input value={selectedDoctor.medico} disabled className="bg-muted/30" />
                </div>

                {/* Clinic management */}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                    <Building2 className="h-3 w-3" /> Clínica
                  </label>
                  <div className="flex gap-2">
                    <Select
                      value={clinics.includes(editClinic) ? editClinic : "__custom__"}
                      onValueChange={v => {
                        if (v !== "__custom__") {
                          setEditClinic(v);
                          setClinicDirty(v !== selectedDoctor.clinica);
                        }
                      }}
                    >
                      <SelectTrigger className="w-[240px]">
                        <SelectValue placeholder="Selecione clínica" />
                      </SelectTrigger>
                      <SelectContent>
                        {clinics.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        <SelectItem value="__custom__">Digitar manualmente...</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      value={editClinic}
                      onChange={e => {
                        setEditClinic(e.target.value);
                        setClinicDirty(e.target.value !== selectedDoctor.clinica);
                      }}
                      placeholder="Nome da clínica"
                      className="flex-1"
                    />
                  </div>
                </div>

                {/* Schedule grid */}
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr>
                        <th className="text-left text-xs font-medium text-muted-foreground p-2 w-24">Dia</th>
                        {PERIODS.map(p => (
                          <th key={p} className="text-center text-xs font-medium text-muted-foreground p-2 w-28">{p}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {DAYS.map((day, dayIdx) => (
                        <tr key={day} className="border-t border-border/50">
                          <td className="p-2 text-sm font-medium text-foreground">{day}</td>
                          {PERIODS.map((period, periodIdx) => {
                            const idx = getIdx(dayIdx, periodIdx);
                            return (
                              <td key={period} className="p-2 text-center">
                                <label className="inline-flex items-center justify-center gap-2 cursor-pointer p-2 rounded-md hover:bg-accent/50 transition-colors">
                                  <Checkbox
                                    checked={schedule[idx]}
                                    onCheckedChange={() => toggleSlot(idx)}
                                  />
                                  <span className="text-xs text-muted-foreground">
                                    {schedule[idx] ? "✓" : "—"}
                                  </span>
                                </label>
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Preview */}
                <div className="flex items-center gap-2 pt-2 border-t border-border/50">
                  <span className="text-xs text-muted-foreground">Código:</span>
                  <Badge variant="secondary" className="text-xs font-mono">
                    {scheduleFlag || "Nenhum horário"}
                  </Badge>
                </div>

                {!apiUrl && (
                  <p className="text-xs text-destructive mt-2">
                    ⚠ Configure a URL da API nas configurações (⚙) para salvar na planilha.
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
