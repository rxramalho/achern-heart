import { useState, useCallback, useMemo, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Doctor,
  PRODUCTS,
  getCategory,
  getCategoryValue,
  parseAvailability,
} from "@/types/doctor";
import {
  MapPin,
  Building2,
  Star,
  Stethoscope,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Plus,
  Trash2,
  Search,
  Lightbulb,
  Calendar,
  Copy,
  ExternalLink,
  Check,
  ClipboardList,
  AlertTriangle,
  Coffee,
  Users,
  Flag,
  Download,
  Upload,
  Route,
  ArrowDownUp,
} from "lucide-react";
import { toast } from "sonner";
import { useRoutingData } from "@/hooks/useRoutingData";

// ── Types ──────────────────────────────────────────────────────────
type DayFlag = "" | "feriado" | "ponte" | "folga" | "reuniao";

const DAY_FLAG_LABELS: Record<DayFlag, string> = {
  "": "Dia útil",
  feriado: "Feriado",
  ponte: "Ponte",
  folga: "Folga",
  reuniao: "Reunião",
};

const DAY_FLAG_COLORS: Record<DayFlag, string> = {
  "": "",
  feriado: "bg-destructive/15 text-destructive border-destructive/30",
  ponte: "bg-orange-500/15 text-orange-700 dark:text-orange-400 border-orange-500/30",
  folga: "bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30",
  reuniao: "bg-purple-500/15 text-purple-700 dark:text-purple-400 border-purple-500/30",
};

const DAY_FLAG_ICONS: Record<DayFlag, typeof Flag> = {
  "": Flag,
  feriado: AlertTriangle,
  ponte: Coffee,
  folga: Coffee,
  reuniao: Users,
};

interface RoutingSlot {
  crm: string;
  doctorName: string;
  productFocus: string;
}

interface MonthRoutingData {
  version: number;
  days: Record<string, RoutingSlot[]>; // "YYYY-MM-DD" → slots
  flags: Record<string, DayFlag>;      // "YYYY-MM-DD" → flag
}

// ── Calendar helpers ───────────────────────────────────────────────
const WEEKDAY_NAMES = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const WEEKDAY_FULL: Record<number, string> = {
  1: "Segunda-feira",
  2: "Terça-feira",
  3: "Quarta-feira",
  4: "Quinta-feira",
  5: "Sexta-feira",
};
const MONTH_NAMES = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

interface CalendarDay {
  date: Date;
  dateKey: string; // "YYYY-MM-DD"
  label: string;   // "Seg 03/03"
  dayOfWeek: number; // 0=Sun ... 6=Sat
  isWeekday: boolean;
}

function getMonthWorkdays(year: number, month: number): CalendarDay[] {
  const days: CalendarDay[] = [];
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(year, month, d);
    const dow = date.getDay();
    if (dow === 0 || dow === 6) continue; // skip weekends
    const dateKey = `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    const label = `${WEEKDAY_NAMES[dow]} ${String(d).padStart(2, "0")}/${String(month + 1).padStart(2, "0")}`;
    days.push({ date, dateKey, label, dayOfWeek: dow, isWeekday: true });
  }
  return days;
}

function getMonthKey(year: number, month: number): string {
  return `standard_routing_${year}-${String(month + 1).padStart(2, "0")}`;
}

// ── Persistence ────────────────────────────────────────────────────
function loadMonthData(year: number, month: number): MonthRoutingData {
  try {
    const raw = localStorage.getItem(getMonthKey(year, month));
    if (!raw) return { version: 1, days: {}, flags: {} };
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || !parsed.days || typeof parsed.days !== "object") {
      return { version: 1, days: {}, flags: {} };
    }
    // Sanitize slots
    const sanitized: Record<string, RoutingSlot[]> = {};
    for (const [key, value] of Object.entries(parsed.days as Record<string, unknown>)) {
      if (!Array.isArray(value)) { sanitized[key] = []; continue; }
      sanitized[key] = value
        .map((s: any) => ({
          crm: String(s?.crm ?? ""),
          doctorName: String(s?.doctorName ?? ""),
          productFocus: String(s?.productFocus ?? ""),
        }))
        .filter((s) => s.crm.trim().length > 0);
    }
    // Sanitize flags
    const validFlags = new Set(["", "feriado", "ponte", "folga", "reuniao"]);
    const flags: Record<string, DayFlag> = {};
    if (parsed.flags && typeof parsed.flags === "object") {
      for (const [key, val] of Object.entries(parsed.flags as Record<string, unknown>)) {
        const v = String(val || "");
        if (validFlags.has(v)) flags[key] = v as DayFlag;
      }
    }
    return { version: Number(parsed.version) || 1, days: sanitized, flags };
  } catch {
    return { version: 1, days: {}, flags: {} };
  }
}

function saveMonthData(year: number, month: number, data: MonthRoutingData) {
  try {
    localStorage.setItem(getMonthKey(year, month), JSON.stringify(data));
  } catch { /* storage full? ignore */ }
}

// ── Scoring ────────────────────────────────────────────────────────
function scoreDoctorForSuggestion(
  doctor: Doctor,
  productFilter: string[],
  dayKey: string,
  allDays: Record<string, RoutingSlot[]>,
): { score: number; bestMarket: string; cat: number } | null {
  // Skip if already on this day
  if ((allDays[dayKey] || []).some((s) => s.crm === doctor.crmPainel)) return null;

  const markets = productFilter.length > 0 ? productFilter : [...PRODUCTS];
  let bestScore = -1;
  let bestMarket = markets[0] || "ALENIA";
  let bestCat = 5;

  for (const m of markets) {
    const cat = getCategory(doctor, m);
    if (!cat) continue;
    const val = getCategoryValue(doctor, m) || 0;
    const s = (6 - cat) * 100 + Math.min(val, 99);
    if (s > bestScore) { bestScore = s; bestMarket = m; bestCat = cat; }
  }
  if (bestScore <= 0) return null;

  // Clinic concentration bonus: how many from same clinic already on this day
  const daySlots = allDays[dayKey] || [];
  const clinicCount = daySlots.filter((s) => {
    // We need to check doctor's clinic - but slots don't store clinic.
    // We'll handle this at the caller level by grouping.
    return false;
  }).length;

  // Week penalty: count how many days this week doctor appears
  // Parse week from dateKey
  const dateObj = new Date(dayKey);
  const weekStart = new Date(dayKey);
  weekStart.setDate(dateObj.getDate() - ((dateObj.getDay() + 6) % 7)); // Monday of that week
  let weekCount = 0;
  for (let i = 0; i < 5; i++) {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + i);
    const k = d.toISOString().slice(0, 10);
    if ((allDays[k] || []).some((s) => s.crm === doctor.crmPainel)) weekCount++;
  }

  const extra = (doctor.scoreClinica || 0) * 0.5 + (doctor.scoreEspecialidade || 0) * 0.3;
  return {
    score: bestScore + extra - weekCount * 50,
    bestMarket,
    cat: bestCat,
  };
}

// ── Short name helper ──────────────────────────────────────────────
const TITLES = new Set(["dr.", "dra.", "dr", "dra"]);
const CONNECTORS = new Set(["de", "da", "do", "das", "dos", "e"]);
function shortName(fullName: string): string {
  const parts = fullName.trim().split(/\s+/).filter(p => !TITLES.has(p.toLowerCase()));
  if (parts.length <= 2) return parts.join(" ");
  const result: string[] = [parts[0]];
  for (let i = 1; i < parts.length; i++) {
    if (CONNECTORS.has(parts[i].toLowerCase())) { result.push(parts[i]); } else { result.push(parts[i]); break; }
  }
  return result.join(" ");
}

// ── Component ──────────────────────────────────────────────────────
const CAT_CLASSES: Record<number, string> = {
  1: "bg-cat1 text-primary-foreground",
  2: "bg-cat2 text-accent-foreground",
  3: "bg-cat3 text-foreground",
  4: "bg-cat4 text-primary-foreground",
  5: "bg-cat5 text-primary-foreground",
};

interface StandardRoutingProps {
  doctors: Doctor[];
}

export default function StandardRouting({ doctors }: StandardRoutingProps) {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const { data, setData, loading: routingLoading } = useRoutingData(year, month);
  const [expandedDays, setExpandedDays] = useState<Set<string>>(new Set());
  const [productFilter, setProductFilter] = useState<string[]>([]);
  const [addDialogDay, setAddDialogDay] = useState<string | null>(null);
  const [addSearch, setAddSearch] = useState("");
  const [suggestionDay, setSuggestionDay] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const [showGenerateRoute, setShowGenerateRoute] = useState(false);
  const [selectedRouteDocsForCopy, setSelectedRouteDocsForCopy] = useState<Set<string>>(new Set());
  const [cityFilter, setCityFilter] = useState<string>("");
  const importFileRef = useRef<HTMLInputElement>(null);

  // Reset expanded days when month changes
  useEffect(() => {
    setExpandedDays(new Set());
  }, [year, month]);

  const workdays = useMemo(() => getMonthWorkdays(year, month), [year, month]);

  const doctorMap = useMemo(() => {
    const map = new Map<string, Doctor>();
    for (const d of doctors) if (d?.crmPainel) map.set(d.crmPainel, d);
    return map;
  }, [doctors]);

  // Unique cities for filter
  const availableCities = useMemo(() => {
    const cities = new Set<string>();
    for (const d of doctors) if (d?.cidade) cities.add(d.cidade);
    return [...cities].sort();
  }, [doctors]);

  const navigateMonth = useCallback((delta: number) => {
    let m = month + delta;
    let y = year;
    if (m < 0) { m = 11; y--; }
    if (m > 11) { m = 0; y++; }
    setYear(y);
    setMonth(m);
  }, [month, year]);

  const toggleDay = useCallback((key: string) => {
    setExpandedDays((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  }, []);

  const setDayFlag = useCallback((dayKey: string, flag: DayFlag) => {
    setData((prev) => {
      const flags = { ...prev.flags };
      if (flag === "") { delete flags[dayKey]; } else { flags[dayKey] = flag; }
      return { ...prev, flags };
    });
  }, []);

  const addSlot = useCallback((dayKey: string, crm: string, doctorName: string, productFocus: string) => {
    setData((prev) => {
      const slots = [...(prev.days[dayKey] || [])];
      if (slots.some((s) => s.crm === crm)) { toast.error("Médico já adicionado neste dia."); return prev; }
      slots.push({ crm, doctorName, productFocus });
      return { ...prev, days: { ...prev.days, [dayKey]: slots } };
    });
    toast.success("Médico adicionado!");
  }, []);

  const removeSlot = useCallback((dayKey: string, idx: number) => {
    setData((prev) => {
      const slots = [...(prev.days[dayKey] || [])];
      slots.splice(idx, 1);
      return { ...prev, days: { ...prev.days, [dayKey]: slots } };
    });
  }, []);

  const moveSlot = useCallback((dayKey: string, fromIdx: number, toIdx: number) => {
    setData((prev) => {
      const slots = [...(prev.days[dayKey] || [])];
      if (toIdx < 0 || toIdx >= slots.length) return prev;
      const [item] = slots.splice(fromIdx, 1);
      slots.splice(toIdx, 0, item);
      return { ...prev, days: { ...prev.days, [dayKey]: slots } };
    });
  }, []);

  const reverseSlots = useCallback((dayKey: string) => {
    setData((prev) => {
      const slots = [...(prev.days[dayKey] || [])];
      if (slots.length < 2) return prev;
      slots.reverse();
      return { ...prev, days: { ...prev.days, [dayKey]: slots } };
    });
    toast.success("Ordem invertida!");
  }, []);

  // Enhanced suggestions: group by clinic, single-period at edges
  const getSuggestions = useCallback((dayKey: string, limit = 15) => {
    const results: { doctor: Doctor; score: number; bestMarket: string; cat: number; periodLabel: string; isRevisit: boolean }[] = [];
    const [y, m, d] = dayKey.split("-").map(Number);
    const dateObj = new Date(y, m - 1, d);
    const dow = dateObj.getDay(); // 1-5 for weekdays
    const dayMap: Record<string, number> = { segunda: 1, terca: 2, quarta: 3, quinta: 4, sexta: 5 };

    for (const doctor of doctors) {
      if (!doctor?.crmPainel) continue;

      // City filter
      if (cityFilter && doctor.cidade !== cityFilter) continue;

      // Check availability for this day of week
      const avail = parseAvailability(doctor.disponibilidade);
      const dayAvail = avail.filter(a => dayMap[a.day] === dow);
      if (dayAvail.length === 0) continue;

      // Period label
      let periodLabel = "";
      for (const a of dayAvail) {
        if (a.period === "Manhã e Tarde") { periodLabel = "MT"; break; }
        if (a.period === "Manhã") periodLabel = periodLabel === "T" ? "MT" : "M";
        else if (a.period === "Tarde") periodLabel = periodLabel === "M" ? "MT" : "T";
        else periodLabel = "MT";
      }

      // Already on this day? Block (never same day)
      if ((data.days[dayKey] || []).some((s) => s.crm === doctor.crmPainel)) continue;

      // Check if revisit (already on another day this month)
      const isRevisit = Object.entries(data.days).some(([k, slots]) => k !== dayKey && slots.some(s => s.crm === doctor.crmPainel));

      const result = scoreDoctorForSuggestion(doctor, productFilter, dayKey, data.days);
      if (result) results.push({ doctor, ...result, periodLabel, isRevisit });
    }

    // Sort by score
    results.sort((a, b) => b.score - a.score);
    const top = results.slice(0, limit);

    // Group by clinic concentration
    const clinicGroups = new Map<string, typeof top>();
    for (const item of top) {
      const clinic = item.doctor.clinica || "Outros";
      if (!clinicGroups.has(clinic)) clinicGroups.set(clinic, []);
      clinicGroups.get(clinic)!.push(item);
    }

    // Sort groups: larger groups first (concentration)
    const sortedGroups = [...clinicGroups.entries()].sort((a, b) => b[1].length - a[1].length);

    // Flatten, placing single-period doctors at edges
    const finalList: typeof top = [];
    const morningOnly: typeof top = [];
    const afternoonOnly: typeof top = [];
    const flexible: typeof top = [];

    for (const [, items] of sortedGroups) {
      for (const item of items) {
        if (item.periodLabel === "M") morningOnly.push(item);
        else if (item.periodLabel === "T") afternoonOnly.push(item);
        else flexible.push(item);
      }
    }

    // Morning-only at start, flexible in middle, afternoon-only at end
    finalList.push(...morningOnly, ...flexible, ...afternoonOnly);
    return finalList;
  }, [doctors, data.days, productFilter, cityFilter]);

  const totalAssigned = useMemo(() => {
    return Object.entries(data.days)
      .filter(([key]) => workdays.some(w => w.dateKey === key))
      .reduce((sum, [, slots]) => sum + slots.length, 0);
  }, [data.days, workdays]);

  const selectedProductsLabel = productFilter.length === 0
    ? "Todos os produtos"
    : productFilter.length <= 2
      ? productFilter.join(", ")
      : `${productFilter.length} produtos`;

  const toggleProduct = (p: string) => {
    setProductFilter((prev) => prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]);
  };

  // Group workdays by week for display
  const weeks = useMemo(() => {
    const result: { weekNum: number; days: CalendarDay[] }[] = [];
    let currentWeek: CalendarDay[] = [];
    let lastWeekNum = -1;

    for (const day of workdays) {
      // Week number: ISO week based on Monday
      const d = new Date(day.date);
      const jan1 = new Date(d.getFullYear(), 0, 1);
      const weekNum = Math.ceil(((d.getTime() - jan1.getTime()) / 86400000 + jan1.getDay()) / 7);

      if (weekNum !== lastWeekNum && currentWeek.length > 0) {
        result.push({ weekNum: lastWeekNum, days: currentWeek });
        currentWeek = [];
      }
      currentWeek.push(day);
      lastWeekNum = weekNum;
    }
    if (currentWeek.length > 0) {
      result.push({ weekNum: lastWeekNum, days: currentWeek });
    }
    return result;
  }, [workdays]);

  // ── Summary / Report ─────────────────────────────────────────────
  const buildSummaryText = useCallback(() => {
    let text = `Roteirização Padrão – ${MONTH_NAMES[month]} ${year}\n\n`;

    for (const week of weeks) {
      const weekHasSlots = week.days.some(d => (data.days[d.dateKey] || []).length > 0);
      if (!weekHasSlots) continue;

      for (const day of week.days) {
        const flag = data.flags?.[day.dateKey] || "";
        if (flag) {
          text += `${day.label} — ${DAY_FLAG_LABELS[flag].toUpperCase()}\n\n`;
          continue;
        }
        const slots = data.days[day.dateKey] || [];
        if (slots.length === 0) continue;

        text += `${day.label}\n`;

        // Group by clinic
        const clinicOrder: string[] = [];
        const clinicMap: Record<string, RoutingSlot[]> = {};
        for (const slot of slots) {
          const doc = doctorMap.get(slot.crm);
          const clinic = doc?.clinica || "Sem clínica";
          if (!clinicMap[clinic]) { clinicMap[clinic] = []; clinicOrder.push(clinic); }
          clinicMap[clinic].push(slot);
        }

        for (const clinic of clinicOrder) {
          text += `  ${clinic.toUpperCase()}\n`;
          for (const slot of clinicMap[clinic]) {
            const doc = doctorMap.get(slot.crm);
            const cat = doc ? getCategory(doc, slot.productFocus) : null;
            const captacoes = doc ? getCategoryValue(doc, slot.productFocus) : 0;
            text += `    ${shortName(slot.doctorName)} | C${cat || "?"} | ${slot.productFocus} | Cap: ${captacoes}\n`;
          }
        }
        text += "\n";
      }
    }
    return text.trim();
  }, [data.days, weeks, month, year, doctorMap]);

  const handleCopy = useCallback(() => {
    const text = buildSummaryText();
    if (!text || totalAssigned === 0) { toast.error("Nenhum médico alocado."); return; }
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Roteiro copiado!");
  }, [buildSummaryText, totalAssigned]);

  const handleGoogleKeep = useCallback(async () => {
    const text = buildSummaryText();
    if (!text || totalAssigned === 0) { toast.error("Nenhum médico alocado."); return; }
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Roteiro copiado! Cole no Google Keep.");
    } catch { toast.info("Abrindo Google Keep..."); }
    window.open("https://keep.google.com/u/0/#NOTE", "_blank");
  }, [buildSummaryText, totalAssigned]);

  // ── Export JSON ───────────────────────────────────────────────────
  const handleExport = useCallback((e?: React.MouseEvent) => {
    if (e) { e.preventDefault(); e.stopPropagation(); }
    const exportData = {
      type: "standard_routing_export",
      version: 1,
      month: month + 1,
      year,
      monthLabel: `${MONTH_NAMES[month]} ${year}`,
      exportedAt: new Date().toISOString(),
      data,
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `roteirizacao_${year}_${String(month + 1).padStart(2, "0")}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 100);
    toast.success("Roteiro exportado!");
  }, [data, month, year]);

  // ── Import JSON ─────────────────────────────────────────────────
  const handleImport = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const parsed = JSON.parse(evt.target?.result as string);
        if (parsed?.type !== "standard_routing_export" || !parsed?.data?.days) {
          toast.error("Arquivo inválido. Use um JSON exportado pela Roteirização Padrão.");
          return;
        }
        // Load into the matching month or current month
        const importMonth = (parsed.month ?? month + 1) - 1;
        const importYear = parsed.year ?? year;
        const importedData: MonthRoutingData = {
          version: 1,
          days: parsed.data.days || {},
          flags: parsed.data.flags || {},
        };
        saveMonthData(importYear, importMonth, importedData);
        // If importing to current view, reload
        if (importYear === year && importMonth === month) {
          setData(importedData);
        } else {
          setYear(importYear);
          setMonth(importMonth);
        }
        toast.success(`Roteiro de ${MONTH_NAMES[importMonth]} ${importYear} importado!`);
      } catch {
        toast.error("Erro ao ler o arquivo JSON.");
      }
    };
    reader.readAsText(file);
    // Reset input so same file can be re-imported
    e.target.value = "";
  }, [month, year]);

  // ── Generate Route (from saved doctors) ─────────────────────────
  const allSavedDoctors = useMemo(() => {
    const seen = new Map<string, { crm: string; name: string; days: string[] }>();
    for (const wd of workdays) {
      const slots = data.days[wd.dateKey] || [];
      for (const slot of slots) {
        if (!seen.has(slot.crm)) {
          seen.set(slot.crm, { crm: slot.crm, name: slot.doctorName, days: [] });
        }
        seen.get(slot.crm)!.days.push(wd.label);
      }
    }
    return [...seen.values()].sort((a, b) => a.name.localeCompare(b.name));
  }, [data.days, workdays]);

  const formatFirstLast = (fullName: string): string => {
    const parts = fullName.trim().split(/\s+/).filter(p => !TITLES.has(p.toLowerCase()));
    if (parts.length <= 1) return parts[0] || fullName;
    const first = parts[0];
    const last = parts[parts.length - 1];
    if (CONNECTORS.has(last.toLowerCase()) && parts.length > 2) return `${first} ${parts[parts.length - 2]}`;
    return `${first} ${last}`;
  };

  // Build compiled route grouped by day > clinic > doctor (matching screenshot layout)
  const compiledRouteByDay = useMemo(() => {
    const selectedCrms = selectedRouteDocsForCopy;
    const result: { dayLabel: string; clinics: { clinic: string; doctors: { num: number; name: string; cat: string; product: string; cap: number; presc: number }[] }[] }[] = [];
    let globalNum = 0;

    for (const wd of workdays) {
      const slots = data.days[wd.dateKey] || [];
      const filtered = slots.filter(s => selectedCrms.has(s.crm));
      if (filtered.length === 0) continue;

      const clinicOrder: string[] = [];
      const clinicMap: Record<string, typeof filtered> = {};
      for (const slot of filtered) {
        const doc = doctorMap.get(slot.crm);
        const clinic = doc?.clinica || "Sem clínica";
        if (!clinicMap[clinic]) { clinicMap[clinic] = []; clinicOrder.push(clinic); }
        clinicMap[clinic].push(slot);
      }

      const clinics = clinicOrder.map(clinic => ({
        clinic,
        doctors: clinicMap[clinic].map(slot => {
          globalNum++;
          const doc = doctorMap.get(slot.crm);
          const cat = doc ? getCategory(doc, slot.productFocus) : null;
          const cap = doc ? getCategoryValue(doc, slot.productFocus) : 0;
          return {
            num: globalNum,
            name: shortName(slot.doctorName).toUpperCase(),
            cat: `C${cat || "?"}`,
            product: slot.productFocus,
            cap,
            presc: cap,
          };
        }),
      }));

      // Day label: e.g. "Quinta-feira"
      const dow = new Date(wd.dateKey).getDay();
      const dayLabel = WEEKDAY_FULL[dow] || wd.label;
      result.push({ dayLabel, clinics });
    }
    return { items: result, total: globalNum };
  }, [workdays, data.days, selectedRouteDocsForCopy, doctorMap]);

  const handleCopyGeneratedRoute = useCallback(() => {
    const { items, total } = compiledRouteByDay;
    if (total === 0) { toast.error("Selecione ao menos um médico."); return; }

    let text = `Roteiro Compilado\n${total} médicos selecionados\n\n`;
    for (const day of items) {
      text += `${day.dayLabel}\n`;
      for (const cl of day.clinics) {
        text += `  ${cl.clinic.toUpperCase()}\n`;
        for (const d of cl.doctors) {
          text += `    ${d.num}. ${d.name}\n`;
          text += `    ${d.cat} | ${d.product} | Cap: ${d.cap} | Presc: ${d.presc}\n`;
        }
      }
      text += "\n";
    }

    navigator.clipboard.writeText(text.trim());
    toast.success("Roteiro copiado!");
    setShowGenerateRoute(false);
  }, [compiledRouteByDay]);

  if (routingLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <p className="text-muted-foreground">Carregando roteirização...</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Hidden file input for import */}
      <input
        type="file"
        accept=".json"
        className="hidden"
        ref={importFileRef}
        onChange={handleImport}
      />
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-primary" />
          <span className="text-sm font-semibold text-foreground">Roteirização Padrão Mensal</span>
          <Badge variant="outline" className="text-xs">{totalAssigned} médicos alocados</Badge>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Month navigation */}
          <div className="flex items-center gap-1 border rounded-md">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => navigateMonth(-1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-xs font-medium px-2 min-w-[110px] text-center">
              {MONTH_NAMES[month]} {year}
            </span>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => navigateMonth(1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Export */}
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={(e) => handleExport(e)} title="Exportar JSON">
            <Download className="h-3.5 w-3.5" />
          </Button>

          {/* Import */}
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => importFileRef.current?.click()} title="Importar JSON">
            <Upload className="h-3.5 w-3.5" />
          </Button>

          {/* Generate Route */}
          <Button
            variant="outline"
            size="sm"
            className="h-8 text-xs gap-1"
            onClick={() => {
              setSelectedRouteDocsForCopy(new Set(allSavedDoctors.map(d => d.crm)));
              setShowGenerateRoute(true);
            }}
          >
            <Route className="h-3.5 w-3.5" />
            Gerar Roteiro
          </Button>

          {/* Product filter */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="h-8 text-xs gap-1">
                <span className="truncate max-w-[140px]">{selectedProductsLabel}</span>
                <ChevronDown className="h-3 w-3 opacity-70" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[240px] p-3" align="end">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium">Filtro de Produto</p>
                  <Button variant="ghost" size="sm" className="h-6 px-2 text-[10px]" onClick={() => setProductFilter([])}>Limpar</Button>
                </div>
                <div className="max-h-52 overflow-y-auto space-y-1.5 pr-1">
                  {PRODUCTS.map((p) => (
                    <label key={p} className="flex items-center gap-2 cursor-pointer">
                      <Checkbox checked={productFilter.includes(p)} onCheckedChange={() => toggleProduct(p)} />
                      <span className="text-xs">{p}</span>
                    </label>
                  ))}
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* City filter */}
          <Select value={cityFilter || "all"} onValueChange={(val) => setCityFilter(val === "all" ? "" : val)}>
            <SelectTrigger className="h-8 w-auto min-w-[100px] text-xs gap-1">
              <SelectValue placeholder="Cidade" />
            </SelectTrigger>
            <SelectContent align="end">
              <SelectItem value="all">Todas as cidades</SelectItem>
              {availableCities.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Weeks */}
      {weeks.map(({ weekNum, days }, weekIdx) => (
        <Card key={`week-${weekNum}-${weekIdx}`}>
          <CardHeader className="pb-2 px-3 pt-3">
            <CardTitle className="text-sm font-semibold text-foreground">
              {weekIdx + 1}ª Semana
            </CardTitle>
          </CardHeader>
          <CardContent className="px-3 pb-3 space-y-2">
            {days.map((calDay) => {
              const slots = data.days[calDay.dateKey] || [];
              const isExpanded = expandedDays.has(calDay.dateKey);
              const isToday = calDay.dateKey === `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
              const dayFlag: DayFlag = data.flags?.[calDay.dateKey] || "";
              const isFlagged = dayFlag !== "";
              const FlagIcon = DAY_FLAG_ICONS[dayFlag];

              return (
                <div key={calDay.dateKey} className={`border rounded-lg ${isToday ? "border-primary ring-1 ring-primary/30" : ""} ${isFlagged ? DAY_FLAG_COLORS[dayFlag] : ""}`}>
                  {/* Day header */}
                  <div className="flex items-center justify-between px-3 py-2">
                    <button
                      className="flex items-center gap-2 text-left hover:opacity-80 transition-opacity flex-1 min-w-0"
                      onClick={() => toggleDay(calDay.dateKey)}
                    >
                      <span className={`text-xs font-medium ${isToday ? "text-primary" : isFlagged ? "" : "text-foreground"}`}>
                        {calDay.label}
                        {isToday && <span className="ml-1 text-[10px] font-normal text-primary">(Hoje)</span>}
                      </span>
                      {isFlagged && (
                        <Badge variant="outline" className={`text-[9px] px-1.5 py-0 gap-1 ${DAY_FLAG_COLORS[dayFlag]}`}>
                          <FlagIcon className="h-2.5 w-2.5" />
                          {DAY_FLAG_LABELS[dayFlag]}
                        </Badge>
                      )}
                      {!isFlagged && slots.length > 0 && (
                        <Badge variant="secondary" className="text-[10px] px-1.5">{slots.length}</Badge>
                      )}
                    </button>
                    <div className="flex items-center gap-1 shrink-0">
                      {/* Day flag selector */}
                      <Select
                        value={dayFlag || "normal"}
                        onValueChange={(val) => setDayFlag(calDay.dateKey, (val === "normal" ? "" : val) as DayFlag)}
                      >
                        <SelectTrigger className="h-7 w-auto min-w-[28px] px-1.5 border bg-background shadow-none text-xs gap-1" onClick={(e) => e.stopPropagation()}>
                          <SelectValue placeholder={<Flag className="h-3 w-3 text-muted-foreground/50" />} />
                        </SelectTrigger>
                        <SelectContent align="end">
                          <SelectItem value="normal">✅ Dia útil</SelectItem>
                          <SelectItem value="feriado">🔴 Feriado</SelectItem>
                          <SelectItem value="ponte">🟠 Ponte</SelectItem>
                          <SelectItem value="folga">🔵 Folga</SelectItem>
                          <SelectItem value="reuniao">🟣 Reunião</SelectItem>
                        </SelectContent>
                      </Select>
                      {slots.length >= 2 && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          title="Inverter ordem dos médicos"
                          onClick={(e) => { e.stopPropagation(); reverseSlots(calDay.dateKey); }}
                        >
                          <ArrowDownUp className="h-3.5 w-3.5 text-muted-foreground" />
                        </Button>
                      )}
                      {isExpanded ? <ChevronUp className="h-3 w-3 text-muted-foreground" /> : <ChevronDown className="h-3 w-3 text-muted-foreground cursor-pointer" onClick={() => toggleDay(calDay.dateKey)} />}
                    </div>
                  </div>

                  {/* Day content */}
                  {isExpanded && (
                    <div className="px-3 pb-3 space-y-2 border-t">
                      {slots.length === 0 ? (
                        <p className="text-[10px] text-muted-foreground text-center py-2">Nenhum médico alocado</p>
                      ) : (
                        <div className="space-y-1 pt-2">
                          {slots.map((slot, idx) => {
                            const doc = doctorMap.get(slot.crm);
                            const cat = doc ? getCategory(doc, slot.productFocus) : null;
                            return (
                              <div key={`${slot.crm}-${idx}`} className="flex items-center gap-1.5 rounded-md border bg-card px-2 py-1.5 text-xs group">
                                <span className="text-[10px] font-bold text-muted-foreground w-4 shrink-0">{idx + 1}.</span>
                                <div className="flex items-center gap-1 shrink-0">
                                  <Button variant="ghost" size="icon" className="h-5 w-5 opacity-0 group-hover:opacity-100" onClick={() => moveSlot(calDay.dateKey, idx, idx - 1)}>
                                    <ChevronUp className="h-3 w-3" />
                                  </Button>
                                  <Button variant="ghost" size="icon" className="h-5 w-5 opacity-0 group-hover:opacity-100" onClick={() => moveSlot(calDay.dateKey, idx, idx + 1)}>
                                    <ChevronDown className="h-3 w-3" />
                                  </Button>
                                </div>
                                <div className="flex-1 min-w-0">
                                  <span className="font-medium text-foreground truncate block">{slot.doctorName}</span>
                                  <span className="text-[10px] text-muted-foreground">{slot.productFocus} | CRM: {slot.crm}</span>
                                </div>
                                {cat && <Badge className={`${CAT_CLASSES[cat]} text-[9px] px-1 py-0 shrink-0`}>C{cat}</Badge>}
                                <Button variant="ghost" size="icon" className="h-5 w-5 text-destructive opacity-0 group-hover:opacity-100 shrink-0" onClick={() => removeSlot(calDay.dateKey, idx)}>
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-2 pt-1">
                        <Button variant="outline" size="sm" className="h-7 text-[10px] flex-1" onClick={() => { setAddDialogDay(calDay.dateKey); setAddSearch(""); }}>
                          <Plus className="h-3 w-3 mr-1" />
                          Adicionar
                        </Button>
                        <Button variant="outline" size="sm" className="h-7 text-[10px] flex-1" onClick={() => setSuggestionDay(calDay.dateKey)}>
                          <Lightbulb className="h-3 w-3 mr-1" />
                          Sugestões
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      ))}

      {/* Summary Box */}
      {totalAssigned > 0 && (
        <Card>
          <CardHeader className="pb-2 px-3 pt-3">
            <CardTitle className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-2 font-semibold text-foreground">
                <ClipboardList className="h-4 w-4 text-primary" />
                Resumo – {MONTH_NAMES[month]} {year}
              </span>
              <Badge variant="secondary" className="text-xs">{totalAssigned} médicos</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="px-3 pb-3 space-y-3">
            {/* Mini summary per day */}
            <div className="max-h-[300px] overflow-y-auto space-y-2">
              {workdays.filter(d => (data.days[d.dateKey] || []).length > 0 || (data.flags?.[d.dateKey] && data.flags[d.dateKey] !== "")).map((calDay) => {
                const flag = data.flags?.[calDay.dateKey] || "";
                if (flag) {
                  const FIcon = DAY_FLAG_ICONS[flag];
                  return (
                    <div key={calDay.dateKey} className="text-xs">
                      <p className="font-semibold text-foreground flex items-center gap-1.5">
                        {calDay.label}
                        <Badge variant="outline" className={`text-[9px] px-1.5 py-0 gap-1 ${DAY_FLAG_COLORS[flag]}`}>
                          <FIcon className="h-2.5 w-2.5" />
                          {DAY_FLAG_LABELS[flag]}
                        </Badge>
                      </p>
                    </div>
                  );
                }
                const slots = data.days[calDay.dateKey] || [];
                // Group by clinic
                const clinicOrder: string[] = [];
                const clinicMap: Record<string, RoutingSlot[]> = {};
                for (const slot of slots) {
                  const doc = doctorMap.get(slot.crm);
                  const clinic = doc?.clinica || "Sem clínica";
                  if (!clinicMap[clinic]) { clinicMap[clinic] = []; clinicOrder.push(clinic); }
                  clinicMap[clinic].push(slot);
                }

                return (
                  <div key={calDay.dateKey} className="text-xs">
                    <p className="font-semibold text-foreground">{calDay.label}</p>
                    {clinicOrder.map((clinic) => (
                      <div key={clinic} className="pl-2 border-l-2 border-primary/30 mt-1 mb-1">
                        <p className="text-[10px] font-bold text-muted-foreground uppercase">{clinic}</p>
                        {clinicMap[clinic].map((slot, i) => {
                          const doc = doctorMap.get(slot.crm);
                          const cat = doc ? getCategory(doc, slot.productFocus) : null;
                          return (
                            <p key={i} className="text-[10px] text-muted-foreground font-mono pl-1">
                              {shortName(slot.doctorName)} · C{cat || "?"} · {slot.productFocus}
                            </p>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>

            <div className="flex gap-2 pt-1">
              <Button variant="outline" className="flex-1 h-9 text-xs" onClick={handleCopy}>
                {copied ? <Check className="h-3.5 w-3.5 mr-1" /> : <Copy className="h-3.5 w-3.5 mr-1" />}
                {copied ? "Copiado!" : "Copiar Roteiro"}
              </Button>
              <Button variant="outline" className="flex-1 h-9 text-xs" onClick={handleGoogleKeep}>
                <ExternalLink className="h-3.5 w-3.5 mr-1" />
                Google Keep
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add Doctor Dialog */}
      <Dialog open={!!addDialogDay} onOpenChange={(open) => { if (!open) setAddDialogDay(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm">
              Adicionar Médico — {workdays.find((d) => d.dateKey === addDialogDay)?.label || addDialogDay}
            </DialogTitle>
            <DialogDescription className="text-xs">Busque e selecione o médico para alocar neste dia.</DialogDescription>
          </DialogHeader>

          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome ou CRM..."
              value={addSearch}
              onChange={(e) => setAddSearch(e.target.value)}
              className="pl-8 h-9 text-xs"
            />
          </div>

          <div className="max-h-64 overflow-y-auto space-y-1">
            {doctors
              .filter((d) => {
                if (!addSearch.trim()) return false;
                const q = addSearch.toLowerCase();
                return (d.medico || "").toLowerCase().includes(q) || (d.crmPainel || "").includes(q);
              })
              .slice(0, 20)
              .map((d) => {
                const marketsToShow = productFilter.length > 0 ? productFilter : [...PRODUCTS];
                let bestMarket = marketsToShow[0];
                let bestCat = 5;
                for (const m of marketsToShow) {
                  const c = getCategory(d, m);
                  if (c && c < bestCat) { bestCat = c; bestMarket = m; }
                }
                const alreadyAdded = addDialogDay ? (data.days[addDialogDay] || []).some((s) => s.crm === d.crmPainel) : false;

                return (
                  <button
                    key={d.crmPainel}
                    disabled={alreadyAdded}
                    className="w-full flex items-center gap-2 rounded-md border px-2.5 py-2 text-left hover:bg-muted/50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                    onClick={() => { if (addDialogDay) addSlot(addDialogDay, d.crmPainel, d.medico, bestMarket); }}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{d.medico}</p>
                      <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                        <span className="flex items-center gap-0.5"><Stethoscope className="h-2.5 w-2.5" />{d.especialidade}</span>
                        <span className="flex items-center gap-0.5"><Building2 className="h-2.5 w-2.5" />{d.clinica}</span>
                        <span className="flex items-center gap-0.5"><MapPin className="h-2.5 w-2.5" />{d.cidade}</span>
                      </div>
                    </div>
                    {bestCat <= 5 && <Badge className={`${CAT_CLASSES[bestCat]} text-[9px] px-1 py-0`}>C{bestCat}</Badge>}
                    <span className="text-[9px] text-primary font-medium shrink-0">{bestMarket}</span>
                  </button>
                );
              })}
            {addSearch.trim() && doctors.filter((d) => {
              const q = addSearch.toLowerCase();
              return (d.medico || "").toLowerCase().includes(q) || (d.crmPainel || "").includes(q);
            }).length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-4">Nenhum médico encontrado</p>
            )}
            {!addSearch.trim() && (
              <p className="text-xs text-muted-foreground text-center py-4">Digite para buscar médicos</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Suggestions Dialog */}
      <Dialog open={!!suggestionDay} onOpenChange={(open) => { if (!open) setSuggestionDay(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm flex items-center gap-2">
              <Lightbulb className="h-4 w-4 text-accent" />
              Sugestões — {workdays.find((d) => d.dateKey === suggestionDay)?.label || suggestionDay}
            </DialogTitle>
            <DialogDescription className="text-xs">
              M = Manhã · T = Tarde · MT = Manhã e Tarde · (R) = Revisita
              {productFilter.length > 0 && ` · ${productFilter.join(", ")}`}
              {cityFilter && ` · ${cityFilter}`}
            </DialogDescription>
          </DialogHeader>

          <div className="max-h-72 overflow-y-auto space-y-1">
            {suggestionDay && getSuggestions(suggestionDay, 15).map(({ doctor, bestMarket, cat, score, periodLabel, isRevisit }, idx) => {
              const captacoes = getCategoryValue(doctor, bestMarket) || 0;
              const suggestions = getSuggestions(suggestionDay, 15);
              const prevDoctor = idx > 0 ? suggestions[idx - 1]?.doctor : null;
              const sameClinic = prevDoctor && prevDoctor.clinica === doctor.clinica && doctor.clinica;

              return (
                <button
                  key={doctor.crmPainel}
                  className={`w-full flex items-center gap-2 rounded-md border px-2.5 py-2 text-left hover:bg-muted/50 transition-colors ${sameClinic ? "ml-2 border-l-2 border-l-primary/30" : ""}`}
                  onClick={() => { if (suggestionDay) addSlot(suggestionDay, doctor.crmPainel, doctor.medico, bestMarket); }}
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">
                      {doctor.medico} <span className="text-primary font-semibold">({periodLabel})</span>
                      {isRevisit && <span className="text-orange-500 dark:text-orange-400 font-semibold ml-1">(R)</span>}
                    </p>
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] text-muted-foreground">
                      <span className="flex items-center gap-0.5"><Stethoscope className="h-2.5 w-2.5" />{doctor.especialidade}</span>
                      <span className="flex items-center gap-0.5"><Building2 className="h-2.5 w-2.5" />{doctor.clinica}</span>
                      <span className="flex items-center gap-0.5"><MapPin className="h-2.5 w-2.5" />{doctor.cidade}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] mt-0.5">
                      {captacoes > 0 && (
                        <span className="flex items-center gap-0.5 font-mono text-primary"><Star className="h-2.5 w-2.5" />{captacoes}</span>
                      )}
                      <span className="text-muted-foreground">Score: {Math.round(score)}</span>
                    </div>
                  </div>
                  <Badge className={`${CAT_CLASSES[cat]} text-[9px] px-1 py-0 shrink-0`}>C{cat}</Badge>
                  <span className="text-[9px] text-primary font-medium shrink-0">{bestMarket}</span>
                </button>
              );
            })}
            {suggestionDay && getSuggestions(suggestionDay, 15).length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-4">Nenhuma sugestão disponível</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Generate Route Dialog - Roteiro Compilado */}
      <Dialog open={showGenerateRoute} onOpenChange={setShowGenerateRoute}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm flex items-center gap-2">
              <ClipboardList className="h-4 w-4 text-primary" />
              Roteiro Compilado
            </DialogTitle>
            <DialogDescription className="text-xs">
              {compiledRouteByDay.total} médicos selecionados
            </DialogDescription>
          </DialogHeader>

          {allSavedDoctors.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-6">Nenhum médico alocado neste mês.</p>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground">{selectedRouteDocsForCopy.size} de {allSavedDoctors.length} selecionados</p>
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm" className="h-6 px-2 text-[10px]" onClick={() => setSelectedRouteDocsForCopy(new Set(allSavedDoctors.map(d => d.crm)))}>
                    Todos
                  </Button>
                  <Button variant="ghost" size="sm" className="h-6 px-2 text-[10px]" onClick={() => setSelectedRouteDocsForCopy(new Set())}>
                    Nenhum
                  </Button>
                </div>
              </div>

              {/* Compiled route preview grouped by day > clinic */}
              <div className="max-h-72 overflow-y-auto space-y-3">
                {compiledRouteByDay.items.map((day, dayIdx) => (
                  <div key={dayIdx}>
                    <p className="text-sm font-semibold text-foreground mb-1">{day.dayLabel}</p>
                    {day.clinics.map((cl, clIdx) => (
                      <div key={clIdx} className="border-l-2 border-primary/40 pl-3 mb-2">
                        <p className="text-xs font-bold text-foreground uppercase">{cl.clinic}</p>
                        {cl.doctors.map((d, dIdx) => (
                          <div key={dIdx} className="pl-2 mb-1">
                            <p className="text-xs font-medium text-foreground">{d.num}. {d.name}</p>
                            <p className="text-[10px] text-muted-foreground">{d.cat} | {d.product} | Cap: {d.cap} | Presc: {d.presc}</p>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                ))}
                {compiledRouteByDay.items.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-4">Selecione médicos para visualizar o roteiro.</p>
                )}
              </div>

              <div className="flex gap-2 pt-1">
                <Button variant="outline" className="flex-1 h-9 text-xs" onClick={handleCopyGeneratedRoute}>
                  <Copy className="h-3.5 w-3.5 mr-1" />
                  Copiar
                </Button>
                <Button variant="outline" className="flex-1 h-9 text-xs" onClick={() => {
                  handleCopyGeneratedRoute();
                  setTimeout(() => window.open("https://keep.google.com/u/0/#NOTE", "_blank"), 200);
                }}>
                  <ExternalLink className="h-3.5 w-3.5 mr-1" />
                  Google Keep
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
