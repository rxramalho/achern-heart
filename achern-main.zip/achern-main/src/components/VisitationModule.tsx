import { useMemo, useState, useCallback, lazy, Suspense, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Doctor,
  PRODUCTS,
  DAY_LABELS,
  DayOfWeek,
  parseAvailability,
  getCategory,
  getCategoryValue,
  shouldVisit,
} from "@/types/doctor";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
const StandardRouting = lazy(() => import("@/components/StandardRouting"));
import {
  MapPin,
  Building2,
  UserCheck,
  Clock,
  Star,
  Stethoscope,
  Filter,
  CalendarDays,
  ChevronDown,
  ChevronRight,
  ClipboardList,
  Copy,
  ExternalLink,
  Check,
  Search,
  Route,
} from "lucide-react";
import { toast } from "sonner";

const CAT_CLASSES: Record<number, string> = {
  1: "bg-cat1 text-primary-foreground",
  2: "bg-cat2 text-accent-foreground",
  3: "bg-cat3 text-foreground",
  4: "bg-cat4 text-primary-foreground",
  5: "bg-cat5 text-primary-foreground",
};

const DAYS_ORDER: DayOfWeek[] = ["segunda", "terca", "quarta", "quinta", "sexta"];

const WEEKDAY_LABELS_PT: Record<DayOfWeek, string> = {
  segunda: "Segunda-feira",
  terca: "Terça-feira",
  quarta: "Quarta-feira",
  quinta: "Quinta-feira",
  sexta: "Sexta-feira",
};

// Old standard routing storage key (legacy cleanup)
const LEGACY_STANDARD_ROUTING_KEY = "standard_routing_data";

interface VisitationModuleProps {
  doctors: Doctor[];
}

type PlannedDoctor = Doctor & {
  score: number;
  daysSince: number;
  bestMarket: string;
  period: string;
};

const TITLES = new Set(["dr.", "dra.", "dr", "dra"]);
const CONNECTORS = new Set(["de", "da", "do", "das", "dos", "e"]);

function shortName(fullName: string): string {
  // Remove titles
  const parts = fullName.trim().split(/\s+/).filter(p => !TITLES.has(p.toLowerCase()));
  if (parts.length === 0) return fullName;
  if (parts.length <= 2) return parts.join(" ");
  // Take first name, then second token (keeping connectors between them if any)
  const result: string[] = [parts[0]];
  for (let i = 1; i < parts.length; i++) {
    if (CONNECTORS.has(parts[i].toLowerCase())) {
      result.push(parts[i]);
    } else {
      result.push(parts[i]);
      break;
    }
  }
  return result.join(" ");
}

function getPeriodOrder(period: string): number {
  if (period === "Manhã") return 0;
  if (period === "Manhã e Tarde" || period === "Integral") return 1;
  if (period === "Tarde") return 2;
  return 1; // unknown → middle
}

/**
 * Sort doctors for routing efficiency:
 * 1. Period (morning first)
 * 2. Within same period: group by clinic (highest-cat doctor anchors the group)
 * 3. Within same clinic+period: by score desc
 */
function sortForRouting(docs: PlannedDoctor[]): PlannedDoctor[] {
  if (docs.length === 0) return docs;

  // Step 1: find the best score per clinic+period group
  const clinicGroupScore: Record<string, number> = {};
  for (const d of docs) {
    const key = `${d.clinica || ""}||${d.period}`;
    clinicGroupScore[key] = Math.max(clinicGroupScore[key] || 0, d.score);
  }

  // Step 2: sort
  return [...docs].sort((a, b) => {
    // Primary: period
    const pA = getPeriodOrder(a.period);
    const pB = getPeriodOrder(b.period);
    if (pA !== pB) return pA - pB;

    // Secondary: clinic group score (higher first so high-potential clinics appear first)
    const keyA = `${a.clinica || ""}||${a.period}`;
    const keyB = `${b.clinica || ""}||${b.period}`;
    const gA = clinicGroupScore[keyA] || 0;
    const gB = clinicGroupScore[keyB] || 0;
    if (gA !== gB) return gB - gA;

    // Tertiary: same clinic groups together
    if (a.clinica !== b.clinica) return (a.clinica || "").localeCompare(b.clinica || "");

    // Within same clinic+period: by individual score
    return b.score - a.score;
  });
}

function StandardRoutingCollapsible({ doctors }: { doctors: Doctor[] }) {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <CollapsibleTrigger asChild>
        <Button variant="outline" className="w-full justify-between gap-2 h-11 text-sm font-semibold group">
          <span className="flex items-center gap-2">
            <Route className="h-4 w-4 text-primary" />
            Roteirização Padrão
          </span>
          <ChevronRight className="h-4 w-4 text-muted-foreground transition-transform group-data-[state=open]:rotate-90" />
        </Button>
      </CollapsibleTrigger>
      <CollapsibleContent className="pt-4">
        {isOpen && (
          <Suspense fallback={<p className="text-xs text-muted-foreground text-center py-4">Carregando...</p>}>
            <StandardRouting doctors={doctors} />
          </Suspense>
        )}
      </CollapsibleContent>
    </Collapsible>
  );
}

function createEmptyWeeklyPlan(): Record<DayOfWeek, PlannedDoctor[]> {
  return { segunda: [], terca: [], quarta: [], quinta: [], sexta: [] };
}

function normalizeDoctor(input: Doctor): Doctor {
  return {
    ...input,
    crmPainel: String(input?.crmPainel ?? ""),
    ufCrm: String(input?.ufCrm ?? ""),
    checkVisitar: String(input?.checkVisitar ?? ""),
    falar: String(input?.falar ?? ""),
    visitadoCiclo: typeof input?.visitadoCiclo === "number" || typeof input?.visitadoCiclo === "string" ? input.visitadoCiclo : 0,
    medico: String(input?.medico ?? ""),
    cat: String(input?.cat ?? ""),
    deltaMedico: String(input?.deltaMedico ?? ""),
    especialidade: String(input?.especialidade ?? ""),
    clinica: String(input?.clinica ?? ""),
    scoreClinica: Number.isFinite(input?.scoreClinica) ? Number(input.scoreClinica) : 0,
    scoreEspecialidade: Number.isFinite(input?.scoreEspecialidade) ? Number(input.scoreEspecialidade) : 0,
    endereco: String(input?.endereco ?? ""),
    cidade: String(input?.cidade ?? ""),
    mercados: input?.mercados && typeof input.mercados === "object" ? input.mercados : {},
    disponibilidade: String(input?.disponibilidade ?? ""),
  };
}

// Legacy cleanup only - remove old format if present

export default function VisitationModule({ doctors }: VisitationModuleProps) {
  // Deferred rendering: don't compute heavy plan until after first paint
  const [ready, setReady] = useState(false);

  const safeDoctors = useMemo(() => {
    try {
      if (!Array.isArray(doctors)) return [];
      return doctors
        .filter((d): d is Doctor => !!d && typeof d === "object")
        .map(normalizeDoctor)
        .filter((d) => d.crmPainel.trim().length > 0);
    } catch (err) {
      console.error("[VisitationModule] Error normalizing doctors:", err);
      return [];
    }
  }, [doctors]);

  useEffect(() => {
    // Clean up legacy storage key
    try {
      localStorage.removeItem(LEGACY_STANDARD_ROUTING_KEY);
    } catch { /* ignore */ }
    // Defer heavy rendering to next frame to prevent white screen
    const raf = requestAnimationFrame(() => {
      setReady(true);
    });
    return () => cancelAnimationFrame(raf);
  }, []);

  // Filters
  const [filterCategories, setFilterCategories] = useState<number[]>([1, 2, 3, 4, 5]);
  const [filterMarkets, setFilterMarkets] = useState<string[]>([]);
  const [filterSpecialties, setFilterSpecialties] = useState<string[]>([]);
  const [filterCity, setFilterCity] = useState("all");
  const [filterClinic, setFilterClinic] = useState("all");
  const [minDaysSinceVisit, setMinDaysSinceVisit] = useState<string>("0");
  const [onlyPending, setOnlyPending] = useState(false);

  // Selection state: ordered array of keys preserving click order
  const [selectionOrder, setSelectionOrder] = useState<string[]>([]);
  const [showRouteDialog, setShowRouteDialog] = useState(false);
  const [copied, setCopied] = useState(false);

  // Per-day search filters
  const [daySearches, setDaySearches] = useState<Record<DayOfWeek, string>>({
    segunda: "", terca: "", quarta: "", quinta: "", sexta: "",
  });
  const setDaySearch = useCallback((day: DayOfWeek, value: string) => {
    setDaySearches((prev) => ({ ...prev, [day]: value }));
  }, []);

  // Per-day pagination to avoid rendering hundreds of cards at once
  const ITEMS_PER_PAGE = 30;
  const [dayLimits, setDayLimits] = useState<Record<DayOfWeek, number>>({
    segunda: ITEMS_PER_PAGE, terca: ITEMS_PER_PAGE, quarta: ITEMS_PER_PAGE, quinta: ITEMS_PER_PAGE, sexta: ITEMS_PER_PAGE,
  });
  const showMore = useCallback((day: DayOfWeek) => {
    setDayLimits((prev) => ({ ...prev, [day]: prev[day] + ITEMS_PER_PAGE }));
  }, []);

  const specialties = useMemo(
    () => [...new Set(safeDoctors.map((d) => d.especialidade).filter(Boolean))].sort(),
    [safeDoctors],
  );
  const cities = useMemo(() => [...new Set(safeDoctors.map((d) => d.cidade).filter(Boolean))].sort(), [safeDoctors]);
  const clinics = useMemo(() => [...new Set(safeDoctors.map((d) => d.clinica).filter(Boolean))].sort(), [safeDoctors]);

  const toggleCategory = (cat: number) => {
    setFilterCategories((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat].sort((a, b) => a - b),
    );
    resetDayLimits();
  };
  const toggleMarket = (market: string) => {
    setFilterMarkets((prev) => (prev.includes(market) ? prev.filter((m) => m !== market) : [...prev, market]));
    resetDayLimits();
  };
  const toggleSpecialty = (specialty: string) => {
    setFilterSpecialties((prev) =>
      prev.includes(specialty) ? prev.filter((s) => s !== specialty) : [...prev, specialty],
    );
    resetDayLimits();
  };
  const clearMarkets = () => { setFilterMarkets([]); resetDayLimits(); };
  const clearSpecialties = () => { setFilterSpecialties([]); resetDayLimits(); };
  const toggleAllCategories = () => {
    setFilterCategories((prev) => (prev.length === 5 ? [] : [1, 2, 3, 4, 5]));
    resetDayLimits();
  };

  const resetDayLimits = () => {
    setDayLimits({ segunda: ITEMS_PER_PAGE, terca: ITEMS_PER_PAGE, quarta: ITEMS_PER_PAGE, quinta: ITEMS_PER_PAGE, sexta: ITEMS_PER_PAGE });
  };

  // visitadoCiclo = coluna E da COMPILADO = dias desde a última visita
  const getDaysSinceVisit = (doctor: Doctor): number => {
    const val =
      typeof doctor.visitadoCiclo === "string" ? parseInt(doctor.visitadoCiclo, 10) : doctor.visitadoCiclo;
    if (isNaN(val)) return 0;
    return Math.max(0, val);
  };

  const getBestMarketForDoctor = (doctor: Doctor): { market: string; cat: number; captacoes: number } => {
    const marketsToEvaluate = filterMarkets.length > 0 ? filterMarkets : PRODUCTS;
    let best = { market: marketsToEvaluate[0] || "ALENIA", cat: 5, captacoes: 0, scoreBase: -Infinity };
    for (const market of marketsToEvaluate) {
      const cat = getCategory(doctor, market) || 5;
      const captacoes = getCategoryValue(doctor, market) || 0;
      const scoreBase = (6 - cat) * 100 + Math.min(captacoes, 99);
      if (scoreBase > best.scoreBase) best = { market, cat, captacoes, scoreBase };
    }
    return { market: best.market, cat: best.cat, captacoes: best.captacoes };
  };

  const matchesSelectedMarkets = (doctor: Doctor) => {
    if (filterMarkets.length === 0) return true;
    return filterMarkets.some((market) => {
      const cat = getCategory(doctor, market);
      const captacoes = getCategoryValue(doctor, market);
      return !!cat || captacoes > 0;
    });
  };

  const isVisitedByCurrentLogic = (doctor: Doctor) => shouldVisit(doctor);

  const weeklyPlan = useMemo(() => {
    if (!ready) return createEmptyWeeklyPlan();
    try {
      const eligible = safeDoctors.filter((d) => {
        if (onlyPending && isVisitedByCurrentLogic(d)) return false;
        if (!matchesSelectedMarkets(d)) return false;
        const bestMarket = getBestMarketForDoctor(d);
        if (bestMarket.cat && !filterCategories.includes(bestMarket.cat)) return false;
        if (filterSpecialties.length > 0 && !filterSpecialties.includes(d.especialidade)) return false;
        if (filterCity !== "all" && d.cidade !== filterCity) return false;
        if (filterClinic !== "all" && d.clinica !== filterClinic) return false;
        if (getDaysSinceVisit(d) < minDaysSinceVisitAsNumber(minDaysSinceVisit)) return false;
        return true;
      });

      const plan = createEmptyWeeklyPlan();

      for (const d of eligible) {
        const avail = parseAvailability(d.disponibilidade);
        const daysSince = getDaysSinceVisit(d);
        const bestMarket = getBestMarketForDoctor(d);
        const score = (6 - bestMarket.cat) * 100 + daysSince * 10 + Math.min(bestMarket.captacoes, 99);

        if (avail.length === 0) {
          for (const day of DAYS_ORDER) {
            plan[day].push({ ...d, score, daysSince, bestMarket: bestMarket.market, period: "Integral" });
          }
        } else {
          for (const a of avail) {
            if (DAYS_ORDER.includes(a.day)) {
              plan[a.day].push({ ...d, score, daysSince, bestMarket: bestMarket.market, period: a.period });
            }
          }
        }
      }

      for (const day of DAYS_ORDER) {
        plan[day] = sortForRouting(plan[day]);
      }

      return plan;
    } catch (error) {
      console.error("[VisitationModule] Erro ao montar roteiro semanal:", error);
      return createEmptyWeeklyPlan();
    }
  }, [ready, safeDoctors, filterCategories, filterMarkets, filterSpecialties, filterCity, filterClinic, minDaysSinceVisit, onlyPending]);

  const totalSuggested = DAYS_ORDER.reduce((sum, day) => sum + weeklyPlan[day].length, 0);

  const toggleSelect = useCallback((key: string) => {
    setSelectionOrder((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
  }, []);

  const totalSelected = selectionOrder.length;

  const selectionOrderLookup = useMemo(() => {
    const map = new Map<string, number>();
    selectionOrder.forEach((key, idx) => {
      map.set(key, idx + 1);
    });
    return map;
  }, [selectionOrder]);

  // Resolve a selected key to its PlannedDoctor
  const resolveSelected = useCallback((key: string): (PlannedDoctor & { _day: DayOfWeek }) | null => {
    const parts = key.split("-");
    const day = parts[0] as DayOfWeek;
    const idx = parseInt(parts[parts.length - 1], 10);
    const d = weeklyPlan[day]?.[idx];
    if (!d) return null;
    return { ...d, _day: day };
  }, [weeklyPlan]);

  const getTotalPrescriptionsForDoctor = (d: Doctor, market: string): number => {
    const m = d.mercados?.[market];
    if (!m) return 0;
    return (m.cat1 || 0) + (m.cat2 || 0) + (m.cat3 || 0) + (m.cat4 || 0) + (m.cat5 || 0);
  };

  // Build route report grouped by clinic, preserving selection order
  const buildRouteReport = useCallback(() => {
    const byDay: Record<DayOfWeek, (PlannedDoctor & { visitNum: number })[]> = {
      segunda: [], terca: [], quarta: [], quinta: [], sexta: [],
    };

    // Collect selected doctors per day in selection order
    let visitCounter: Record<DayOfWeek, number> = {
      segunda: 0, terca: 0, quarta: 0, quinta: 0, sexta: 0,
    };

    for (const key of selectionOrder) {
      const resolved = resolveSelected(key);
      if (!resolved) continue;
      const day = resolved._day;
      visitCounter[day]++;
      byDay[day].push({ ...resolved, visitNum: visitCounter[day] });
    }

    // Group by clinic within each day, preserving first-appearance order
    const result: { day: DayOfWeek; clinicGroups: { clinic: string; doctors: (PlannedDoctor & { visitNum: number })[] }[] }[] = [];

    for (const day of DAYS_ORDER) {
      const dayDocs = byDay[day];
      if (dayDocs.length === 0) continue;

      const clinicOrder: string[] = [];
      const clinicMap: Record<string, (PlannedDoctor & { visitNum: number })[]> = {};

      for (const d of dayDocs) {
        const clinic = d.clinica || "Sem clínica";
        if (!clinicMap[clinic]) {
          clinicMap[clinic] = [];
          clinicOrder.push(clinic);
        }
        clinicMap[clinic].push(d);
      }

      result.push({
        day,
        clinicGroups: clinicOrder.map((clinic) => ({ clinic, doctors: clinicMap[clinic] })),
      });
    }

    return result;
  }, [weeklyPlan, selectionOrder, resolveSelected]);

  const getRouteText = useCallback(() => {
    const report = buildRouteReport();
    if (report.length === 0) return "";

    const today = new Date();
    const dateStr = `${String(today.getDate()).padStart(2, "0")}/${String(today.getMonth() + 1).padStart(2, "0")}`;

    let text = "";
    for (const { day, clinicGroups } of report) {
      text += `Roteiro – ${dateStr} – ${WEEKDAY_LABELS_PT[day]}\n\n`;
      for (const { clinic, doctors } of clinicGroups) {
        text += `${clinic.toUpperCase()}\n\n`;
        for (const d of doctors) {
          const cat = getCategory(d, d.bestMarket);
          const captacoes = getCategoryValue(d, d.bestMarket);
          const prescricoes = getTotalPrescriptionsForDoctor(d, d.bestMarket);
          text += `${d.visitNum}. ${shortName(d.medico)}\n`;
          text += `   Categoria C${cat || "?"}\n`;
          text += `   Produto Foco: ${d.bestMarket}\n`;
          text += `   Captações: ${captacoes}\n`;
          text += `   Prescrições: ${prescricoes}\n\n`;
        }
      }
    }
    return text.trim();
  }, [buildRouteReport]);

  const handleCopyRoute = useCallback(() => {
    const text = getRouteText();
    if (!text) {
      toast.error("Selecione ao menos um médico para gerar o roteiro.");
      return;
    }
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Roteiro copiado!");
  }, [getRouteText]);

  const handleGoogleKeep = useCallback(async () => {
    const report = buildRouteReport();
    if (report.length === 0) {
      toast.error("Selecione ao menos um médico para gerar o roteiro.");
      return;
    }
    const today = new Date();
    const dateStr = `${String(today.getDate()).padStart(2, "0")}/${String(today.getMonth() + 1).padStart(2, "0")}`;

    let fullText = "";
    for (const { day, clinicGroups } of report) {
      const title = `Roteiro – ${dateStr} – ${WEEKDAY_LABELS_PT[day]}`;
      fullText += `${title}\n\n`;
      for (const { clinic, doctors } of clinicGroups) {
        fullText += `${clinic.toUpperCase()}\n\n`;
        for (const d of doctors) {
          const cat = getCategory(d, d.bestMarket);
          const captacoes = getCategoryValue(d, d.bestMarket);
          const prescricoes = getTotalPrescriptionsForDoctor(d, d.bestMarket);
          fullText += `${d.visitNum}. ${shortName(d.medico)}\n`;
          fullText += `Categoria C${cat || "?"}\n`;
          fullText += `Produto Foco: ${d.bestMarket}\n`;
          fullText += `Captações: ${captacoes}\n`;
          fullText += `Prescrições: ${prescricoes}\n\n`;
        }
      }
      fullText += "---\n\n";
    }

    try {
      await navigator.clipboard.writeText(fullText.trim());
      toast.success("Roteiro copiado! Cole no Google Keep. Abrindo Google Keep...");
    } catch {
      toast.info("Abrindo Google Keep...");
    }

    window.open("https://keep.google.com/u/0/#NOTE", "_blank");
  }, [buildRouteReport]);

  const selectedMarketsLabel =
    filterMarkets.length === 0
      ? "Todos os mercados"
      : filterMarkets.length <= 2
        ? filterMarkets.join(", ")
        : `${filterMarkets.length} mercados`;

  const selectedSpecialtiesLabel =
    filterSpecialties.length === 0
      ? "Todas as especialidades"
      : filterSpecialties.length <= 2
        ? filterSpecialties.join(", ")
        : `${filterSpecialties.length} especialidades`;

  if (!ready) {
    return (
      <div className="flex items-center justify-center py-12">
        <p className="text-sm text-muted-foreground">Carregando Roteiro Semanal...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base font-semibold">
            <Filter className="h-4 w-4 text-primary" />
            Filtros de Visitação
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Category checkboxes */}
          <div>
            <Label className="text-sm font-medium text-foreground mb-2 block">Categorias</Label>
            <div className="flex flex-wrap gap-3">
              {[1, 2, 3, 4, 5].map((cat) => (
                <label key={cat} className="flex items-center gap-2 cursor-pointer">
                  <Checkbox checked={filterCategories.includes(cat)} onCheckedChange={() => toggleCategory(cat)} />
                  <Badge className={`${CAT_CLASSES[cat]} text-xs`}>CAT {cat}</Badge>
                </label>
              ))}
              <Button type="button" variant="outline" size="sm" className="h-7" onClick={toggleAllCategories}>
                {filterCategories.length === 5 ? "Desmarcar todas" : "Marcar todas"}
              </Button>
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            {/* Mercados */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-[220px] justify-between font-normal">
                  <span className="truncate">{selectedMarketsLabel}</span>
                  <ChevronDown className="h-4 w-4 opacity-70" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[260px] p-3" align="start">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">Mercados</p>
                    <Button type="button" variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={clearMarkets}>Limpar</Button>
                  </div>
                  <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                    {PRODUCTS.map((market) => (
                      <label key={market} className="flex items-center gap-2 cursor-pointer">
                        <Checkbox checked={filterMarkets.includes(market)} onCheckedChange={() => toggleMarket(market)} />
                        <span className="text-sm">{market}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </PopoverContent>
            </Popover>

            {/* Especialidades */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-[240px] justify-between font-normal">
                  <span className="truncate">{selectedSpecialtiesLabel}</span>
                  <ChevronDown className="h-4 w-4 opacity-70" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[280px] p-3" align="start">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">Especialidades</p>
                    <Button type="button" variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={clearSpecialties}>Limpar</Button>
                  </div>
                  <div className="max-h-64 overflow-y-auto space-y-2 pr-1">
                    {specialties.map((s) => (
                      <label key={s} className="flex items-center gap-2 cursor-pointer">
                        <Checkbox checked={filterSpecialties.includes(s)} onCheckedChange={() => toggleSpecialty(s)} />
                        <span className="text-sm">{s}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </PopoverContent>
            </Popover>

            <Select value={filterCity} onValueChange={setFilterCity}>
              <SelectTrigger className="w-[150px]"><SelectValue placeholder="Cidade" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                {cities.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>

            <Select value={filterClinic} onValueChange={setFilterClinic}>
              <SelectTrigger className="w-[170px]"><SelectValue placeholder="Clínica" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                {clinics.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>

            <Select value={minDaysSinceVisit} onValueChange={setMinDaysSinceVisit}>
              <SelectTrigger className="w-[170px]"><SelectValue placeholder="Dias sem visita" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">Qualquer tempo</SelectItem>
                <SelectItem value="3">≥ 3 dias sem visita</SelectItem>
                <SelectItem value="5">≥ 5 dias sem visita</SelectItem>
                <SelectItem value="10">≥ 10 dias sem visita</SelectItem>
                <SelectItem value="15">≥ 15 dias sem visita</SelectItem>
                <SelectItem value="30">≥ 30 dias sem visita</SelectItem>
                <SelectItem value="60">≥ 60 dias sem visita</SelectItem>
                <SelectItem value="90">≥ 90 dias sem visita</SelectItem>
                <SelectItem value="120">≥ 120 dias sem visita</SelectItem>
              </SelectContent>
            </Select>

            <label className="flex items-center gap-2 cursor-pointer px-2">
              <Checkbox checked={onlyPending} onCheckedChange={(v) => setOnlyPending(!!v)} />
              <span className="text-sm text-foreground">Apenas pendentes</span>
            </label>
          </div>
        </CardContent>
      </Card>

      {/* Summary + Generate Route */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="text-sm px-3 py-1 border-primary text-primary">
            <CalendarDays className="h-3.5 w-3.5 mr-1.5" />
            {totalSuggested} sugestões na semana
          </Badge>
          <span className="text-xs text-muted-foreground">
            Ordenados por: período → clínica → potencial
          </span>
        </div>

        <div className="flex items-center gap-2">
          {totalSelected > 0 && (
            <Badge variant="secondary" className="text-xs">
              {totalSelected} selecionado{totalSelected > 1 ? "s" : ""}
            </Badge>
          )}
          <Button
            size="sm"
            onClick={() => {
              if (totalSelected === 0) {
                toast.error("Selecione ao menos um médico.");
                return;
              }
              setShowRouteDialog(true);
            }}
          >
            <ClipboardList className="h-4 w-4 mr-1" />
            Gerar Roteiro
          </Button>
          {totalSelected > 0 && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setSelectionOrder([]);
                setDaySearches({ segunda: "", terca: "", quarta: "", quinta: "", sexta: "" });
                toast.success("Seleção limpa!");
              }}
            >
              Limpar Roteirização
            </Button>
          )}
        </div>
      </div>

      {/* Weekly Plan */}
      <div className="grid gap-4 md:grid-cols-5">
        {DAYS_ORDER.map((day) => {
          const dayDoctors = weeklyPlan[day] || [];
          const todayDayOfWeek = new Date().getDay();
          const dayIndex = DAYS_ORDER.indexOf(day) + 1;
          const isToday = todayDayOfWeek === dayIndex;
          const limit = dayLimits[day];

          // Optimized filtering/indexing to avoid freezing with large datasets
          const searchTerm = daySearches[day].toLowerCase().trim();
          const visibleDoctors: { doctor: PlannedDoctor; originalIdx: number }[] = [];
          let matchedCount = 0;

          if (!searchTerm) {
            matchedCount = dayDoctors.length;
            const capped = dayDoctors.slice(0, limit);
            for (let i = 0; i < capped.length; i++) {
              visibleDoctors.push({ doctor: capped[i], originalIdx: i });
            }
          } else {
            for (let i = 0; i < dayDoctors.length; i++) {
              const doctor = dayDoctors[i];
              if ((doctor.medico ?? "").toLowerCase().includes(searchTerm)) {
                matchedCount++;
                if (visibleDoctors.length < limit) {
                  visibleDoctors.push({ doctor, originalIdx: i });
                }
              }
            }
          }

          const hasMore = matchedCount > limit;

          return (
            <Card
              key={day}
              className={`${isToday ? "border-primary ring-1 ring-primary/30" : ""}`}
            >
              <CardHeader className="pb-2 px-3 pt-3">
                <CardTitle className="flex items-center justify-between text-sm gap-1">
                  <span className={`font-semibold shrink-0 ${isToday ? "text-primary" : "text-foreground"}`}>
                    {DAY_LABELS[day]}
                    {isToday && <span className="ml-1 text-[10px] font-normal text-primary">(Hoje)</span>}
                  </span>
                  <div className="flex items-center gap-1">
                    <div className="relative">
                      <Search className="absolute left-1.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                      <input
                        type="text"
                        value={daySearches[day]}
                        onChange={(e) => setDaySearch(day, e.target.value)}
                        placeholder="Buscar..."
                        className="h-6 w-24 rounded border border-input bg-background pl-5 pr-1.5 text-[10px] placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                      />
                    </div>
                    <Badge variant="secondary" className="text-[10px] px-1.5 shrink-0">
                      {matchedCount}
                    </Badge>
                  </div>
                </CardTitle>
              </CardHeader>

              <CardContent className="px-3 pb-3 space-y-2 max-h-[600px] overflow-y-auto">
                {matchedCount === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">Nenhum médico sugerido</p>
                ) : (
                  <>
                    {visibleDoctors.map(({ doctor: d, originalIdx }, i) => {
                      const cat = getCategory(d, d.bestMarket);
                      const captacoes = getCategoryValue(d, d.bestMarket);
                      const selKey = `${day}-${d.crmPainel}-${originalIdx}`;
                      const visitNum = selectionOrderLookup.get(selKey) ?? 0;
                      const isSelected = visitNum > 0;

                      const prevDoc = i > 0 ? visibleDoctors[i - 1].doctor : null;
                      const sameClinicAsPrev = prevDoc && prevDoc.clinica === d.clinica && prevDoc.period === d.period && d.clinica;

                      return (
                        <div
                          key={selKey}
                          className={`rounded-lg border p-2.5 space-y-1.5 transition-shadow cursor-pointer ${
                            isSelected
                              ? "bg-primary/5 border-primary/40 ring-1 ring-primary/20"
                              : "bg-card hover:shadow-sm"
                          } ${sameClinicAsPrev ? "ml-2 border-l-2 border-l-primary/30" : ""}`}
                          onClick={() => toggleSelect(selKey)}
                        >
                          <div className="flex items-start gap-2">
                            <div className="flex flex-col items-center gap-0.5 shrink-0 mt-0.5">
                              <Checkbox
                                checked={isSelected}
                                onCheckedChange={() => toggleSelect(selKey)}
                                onClick={(e) => e.stopPropagation()}
                              />
                              {isSelected && (
                                <span className="text-[9px] font-bold text-primary leading-none">#{visitNum}</span>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-1">
                                <p className="text-xs font-semibold text-foreground leading-tight">{d.medico}</p>
                                {cat && (
                                  <Badge className={`${CAT_CLASSES[cat]} text-[9px] px-1.5 py-0 shrink-0`}>C{cat}</Badge>
                                )}
                              </div>

                              <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[10px] text-muted-foreground mt-1">
                                <span className="flex items-center gap-0.5">
                                  <Stethoscope className="h-2.5 w-2.5" />
                                  {d.especialidade || "—"}
                                </span>
                                <span className="flex items-center gap-0.5">
                                  <MapPin className="h-2.5 w-2.5" />
                                  {d.cidade || "—"}
                                </span>
                              </div>

                              <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-[10px] text-muted-foreground">
                                <span className="flex items-center gap-0.5">
                                  <Building2 className="h-2.5 w-2.5" />
                                  <span className="truncate max-w-[100px]">{d.clinica || "—"}</span>
                                </span>
                                <span className="flex items-center gap-0.5">
                                  <Clock className="h-2.5 w-2.5" />
                                  {d.period}
                                </span>
                              </div>

                              <div className="flex items-center justify-between pt-0.5">
                                <div className="flex items-center gap-2 text-[10px]">
                                  {captacoes > 0 && (
                                    <span className="flex items-center gap-0.5 font-mono font-semibold text-primary">
                                      <Star className="h-2.5 w-2.5" />
                                      {captacoes}
                                    </span>
                                  )}
                                  <span className="flex items-center gap-0.5 text-cat4">
                                    <UserCheck className="h-2.5 w-2.5" />
                                    {d.daysSince}d atrás
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-[9px] text-primary font-medium">{d.bestMarket}</span>
                                  <span className="font-mono text-[9px] text-muted-foreground">{d.crmPainel}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    {hasMore && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full text-xs text-muted-foreground"
                        onClick={() => showMore(day)}
                      >
                        Ver mais ({matchedCount - limit} restantes)
                      </Button>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Standard Routing - Collapsible (lazy rendered) */}
      <StandardRoutingCollapsible doctors={safeDoctors} />

      {/* Route Report Dialog */}
      <Dialog open={showRouteDialog} onOpenChange={setShowRouteDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ClipboardList className="h-5 w-5 text-primary" />
              Roteiro Compilado
            </DialogTitle>
            <DialogDescription>
              {totalSelected} médico{totalSelected > 1 ? "s" : ""} selecionado{totalSelected > 1 ? "s" : ""}
            </DialogDescription>
          </DialogHeader>

           <div className="space-y-4 max-h-[400px] overflow-y-auto">
            {buildRouteReport().map(({ day, clinicGroups }) => (
              <div key={day}>
                <p className="text-sm font-semibold text-foreground mb-2">
                  {WEEKDAY_LABELS_PT[day]}
                </p>
                {clinicGroups.map(({ clinic, doctors }) => (
                  <div key={clinic} className="mb-3 pl-2 border-l-2 border-primary/30">
                    <p className="text-xs font-bold text-foreground uppercase mb-1">{clinic}</p>
                    {doctors.map((d, idx) => {
                      const cat = getCategory(d, d.bestMarket);
                      const captacoes = getCategoryValue(d, d.bestMarket);
                      const prescricoes = getTotalPrescriptionsForDoctor(d, d.bestMarket);
                      return (
                        <div key={idx} className="text-xs text-muted-foreground font-mono mb-2 pl-2">
                          <p className="font-semibold text-foreground">{d.visitNum}. {shortName(d.medico)}</p>
                          <p>C{cat || "?"} | {d.bestMarket} | Cap: {captacoes} | Presc: {prescricoes}</p>
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            ))}

            {buildRouteReport().length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">Nenhum médico selecionado.</p>
            )}
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="outline" className="flex-1" onClick={handleCopyRoute}>
              {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
              {copied ? "Copiado!" : "Copiar"}
            </Button>
            <Button variant="outline" className="flex-1" onClick={handleGoogleKeep}>
              <ExternalLink className="h-4 w-4 mr-1" />
              Google Keep
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function minDaysSinceVisitAsNumber(value: string) {
  return parseInt(value, 10) || 0;
}
