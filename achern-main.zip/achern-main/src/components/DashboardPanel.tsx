import { useMemo, useState, useCallback, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Doctor,
  getCategory,
  getCategoryValue,
  getCurrentWorkingDay,
  shouldVisit,
  getTotalPrescriptions,
  PRODUCTS,
} from "@/types/doctor";
import {
  Users,
  UserCheck,
  UserX,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  MapPin,
  Target,
  Activity,
  Building2,
  Stethoscope,
  ShieldAlert,
  Zap,
  BarChart3,
} from "lucide-react";

interface DashboardPanelProps {
  doctors: Doctor[];
  filterMarkets: string[];
  filterSpecialties: string[];
  filterCities: string[];
  filterClinics: string[];
  minDaysSinceVisit: number;
}

const DEFAULT_FOCUS_SPECIALTIES: string[] = [];

const FOCUS_STORAGE_KEY = "dashboard_focus_specialties";
const WORKED_DAYS_STORAGE_KEY = "dashboard_worked_days";
const CAPTATION_CITIES = ["Natal", "João Câmara", "Ceará-Mirim"];

function getMonthDays(year: number, month: number) {
  const days: { date: Date; label: string; isWeekend: boolean }[] = [];
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  for (let d = 1; d <= daysInMonth; d++) {
    const dt = new Date(year, month, d);
    const dow = dt.getDay();
    days.push({
      date: dt,
      label: `${d}`,
      isWeekend: dow === 0 || dow === 6,
    });
  }
  return days;
}

const WEEKDAY_NAMES = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

const CAT_COLORS: Record<number, string> = {
  1: "bg-blue-500",
  2: "bg-teal-500",
  3: "bg-yellow-500",
  4: "bg-orange-500",
  5: "bg-red-500",
};
const CAT_TEXT: Record<number, string> = {
  1: "text-blue-600",
  2: "text-teal-600",
  3: "text-yellow-600",
  4: "text-orange-600",
  5: "text-red-600",
};

export default function DashboardPanel({
  doctors,
  filterMarkets,
  filterSpecialties,
  filterCities,
  filterClinics,
  minDaysSinceVisit,
}: DashboardPanelProps) {
  const currentWorkingDay = getCurrentWorkingDay();

  // visitadoCiclo = coluna E da COMPILADO = dias desde a última visita
  const getDaysSince = (doctor: Doctor): number => {
    const val =
      typeof doctor.visitadoCiclo === "string"
        ? parseInt(doctor.visitadoCiclo, 10)
        : doctor.visitadoCiclo;
    if (isNaN(val)) return 0;
    return Math.max(0, val);
  };

  // Calendar worked days state — persisted in localStorage, excludes today
  const today = new Date();
  const todayDate = today.getDate();
  const monthKey = `${today.getFullYear()}-${today.getMonth()}`;
  const monthDays = useMemo(() => getMonthDays(today.getFullYear(), today.getMonth()), []);

  // Default worked days: all weekdays up to (but NOT including) today
  const defaultWorkedDays = useMemo(() => {
    const s = new Set<number>();
    for (const md of monthDays) {
      if (!md.isWeekend && md.date.getDate() < todayDate) s.add(md.date.getDate());
    }
    return s;
  }, [monthDays, todayDate]);

  const [workedDaysSet, setWorkedDaysSet] = useState<Set<number>>(() => {
    try {
      const stored = localStorage.getItem(WORKED_DAYS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed?.monthKey === monthKey && Array.isArray(parsed?.days)) {
          const validDays = parsed.days
            .map((d: unknown) => Number(d))
            .filter((d: number) => Number.isInteger(d) && d > 0 && d < todayDate);
          return new Set<number>(validDays);
        }
      }
    } catch {
      // ignore invalid localStorage payload
    }
    return defaultWorkedDays;
  });
  const [calendarOpen, setCalendarOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem(
      WORKED_DAYS_STORAGE_KEY,
      JSON.stringify({
        monthKey,
        days: Array.from(workedDaysSet),
      }),
    );
  }, [workedDaysSet, monthKey]);

  // Focus specialties — persisted in localStorage
  const allSpecialties = useMemo(() => {
    const s = new Set<string>();
    doctors.forEach((d) => { if (d.especialidade) s.add(d.especialidade); });
    return Array.from(s).sort();
  }, [doctors]);

  const [focusSpecialties, setFocusSpecialties] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(FOCUS_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch { /* ignore */ }
    return [];
  });
  const [focusPickerOpen, setFocusPickerOpen] = useState(false);

  const toggleFocusSpec = useCallback((spec: string) => {
    setFocusSpecialties((prev) => {
      const next = prev.includes(spec) ? prev.filter((s) => s !== spec) : [...prev, spec];
      localStorage.setItem(FOCUS_STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const toggleWorkedDay = useCallback((day: number) => {
    // Never allow toggling current day or future days
    if (day >= todayDate) return;

    setWorkedDaysSet((prev) => {
      const next = new Set(prev);
      if (next.has(day)) next.delete(day);
      else next.add(day);

      // Persist immediately to avoid state loss on unexpected reload/crash
      try {
        localStorage.setItem(
          WORKED_DAYS_STORAGE_KEY,
          JSON.stringify({
            monthKey,
            days: Array.from(next),
          }),
        );
      } catch {
        // ignore storage write errors
      }

      return next;
    });
  }, [todayDate, monthKey]);

  const workedDaysCount = workedDaysSet.size;

  const getBestCat = (doctor: Doctor): number => {
    const marketsToCheck =
      filterMarkets.length > 0
        ? filterMarkets
        : Object.keys(doctor.mercados);
    let best = 5;
    for (const m of marketsToCheck) {
      const cat = getCategory(doctor, m);
      if (cat && cat < best) best = cat;
    }
    return best;
  };

  const hasCaptation = (doctor: Doctor): boolean => {
    const markets = filterMarkets.length > 0 ? filterMarkets : Object.keys(doctor.mercados);
    return markets.some((m) => getTotalPrescriptions(doctor, m) > 0);
  };

  const filtered = useMemo(() => {
    return doctors.filter((d) => {
      if (filterSpecialties.length > 0 && !filterSpecialties.includes(d.especialidade)) return false;
      if (filterCities.length > 0 && !filterCities.includes(d.cidade)) return false;
      if (filterClinics.length > 0 && !filterClinics.includes(d.clinica)) return false;
      if (minDaysSinceVisit > 0 && getDaysSince(d) < minDaysSinceVisit) return false;
      if (filterMarkets.length > 0) {
        const hasActivity = filterMarkets.some((m) => {
          const cat = getCategory(d, m);
          return !!cat || getCategoryValue(d, m) > 0;
        });
        if (!hasActivity) return false;
      }
      return true;
    });
  }, [doctors, filterMarkets, filterSpecialties, filterCities, filterClinics, minDaysSinceVisit]);

  const stats = useMemo(() => {
    const total = filtered.length;
    const visited = filtered.filter((d) => shouldVisit(d)).length;
    const pending = total - visited;
    const visitedPct = total > 0 ? Math.round((visited / total) * 100) : 0;

    // Category counts
    const catCounts: Record<number, { total: number; visited: number }> = {};
    for (let c = 1; c <= 5; c++) catCounts[c] = { total: 0, visited: 0 };
    filtered.forEach((d) => {
      const cat = getBestCat(d);
      if (catCounts[cat]) {
        catCounts[cat].total++;
        if (shouldVisit(d)) catCounts[cat].visited++;
      }
    });

    // Non-audited (zero captation) — use fixed captation cities
    const zeroCaptation = filtered.filter((d) => !hasCaptation(d));
    const renovarMedicos = zeroCaptation
      .filter((d) => CAPTATION_CITIES.some((c) => d.cidade.toLowerCase().includes(c.toLowerCase())))
      .sort((a, b) => {
        // Sort by total captation ascending (worst first)
        const marketsA = filterMarkets.length > 0 ? filterMarkets : Object.keys(a.mercados);
        const marketsB = filterMarkets.length > 0 ? filterMarkets : Object.keys(b.mercados);
        const capA = marketsA.reduce((s, m) => s + getTotalPrescriptions(a, m), 0);
        const capB = marketsB.reduce((s, m) => s + getTotalPrescriptions(b, m), 0);
        return capA - capB;
      });
    const zeroCaptOnlyNonRenovar = zeroCaptation
      .filter((d) => !CAPTATION_CITIES.some((c) => d.cidade.toLowerCase().includes(c.toLowerCase())))
      .sort((a, b) => a.cidade.localeCompare(b.cidade));

    // High potential (C1+C2) pending
    const highPotTotal = filtered.filter((d) => getBestCat(d) <= 2).length;
    const highPotVisited = filtered.filter((d) => getBestCat(d) <= 2 && shouldVisit(d)).length;
    const highPotPending = highPotTotal - highPotVisited;
    const highPotPct = highPotTotal > 0 ? Math.round((highPotVisited / highPotTotal) * 100) : 0;

    // Low potential (C4+C5)
    const lowPotTotal = filtered.filter((d) => getBestCat(d) >= 4).length;

    // Good captation volume visited
    const goodCaptation = filtered.filter((d) => getBestCat(d) <= 3);
    const goodCaptVisited = goodCaptation.filter((d) => shouldVisit(d)).length;
    const goodCaptPct = goodCaptation.length > 0 ? Math.round((goodCaptVisited / goodCaptation.length) * 100) : 0;

    // Geographic concentration
    const cityHighPot: Record<string, number> = {};
    filtered.filter((d) => getBestCat(d) <= 2).forEach((d) => {
      cityHighPot[d.cidade] = (cityHighPot[d.cidade] || 0) + 1;
    });
    const cityEntries = Object.entries(cityHighPot).sort((a, b) => b[1] - a[1]);
    const topCity = cityEntries[0];
    const isConcentrated = topCity && highPotTotal > 0 && (topCity[1] / highPotTotal) >= 0.5;

    // Focus specialties — match by exact specialty name from user selection
    const focusData = focusSpecialties.map((spec) => {
      const specLower = spec.toLowerCase();
      const specDocs = filtered.filter((d) => {
        const espLower = d.especialidade.toLowerCase();
        return espLower === specLower || espLower.includes(specLower) || specLower.includes(espLower);
      });
      const specVisited = specDocs.filter((d) => shouldVisit(d)).length;
      return {
        name: spec,
        total: specDocs.length,
        visited: specVisited,
        pct: specDocs.length > 0 ? Math.round((specVisited / specDocs.length) * 100) : 0,
      };
    });

    // Specialties with most captation
    const specCaptation: Record<string, number> = {};
    filtered.forEach((d) => {
      const markets = filterMarkets.length > 0 ? filterMarkets : Object.keys(d.mercados);
      const totalCap = markets.reduce((sum, m) => sum + getTotalPrescriptions(d, m), 0);
      specCaptation[d.especialidade] = (specCaptation[d.especialidade] || 0) + totalCap;
    });
    const topSpecCaptation = Object.entries(specCaptation)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6);

    // Clinics with C1-C5 distribution
    const clinicCats: Record<string, Record<number, number>> = {};
    filtered.forEach((d) => {
      if (!clinicCats[d.clinica]) clinicCats[d.clinica] = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
      const cat = getBestCat(d);
      clinicCats[d.clinica][cat]++;
    });

    // Specialty with C1-C5 distribution
    const specCats: Record<string, Record<number, number>> = {};
    filtered.forEach((d) => {
      if (!specCats[d.especialidade]) specCats[d.especialidade] = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
      const cat = getBestCat(d);
      specCats[d.especialidade][cat]++;
    });

    // Score by clinic (avg)
    const clinicScores: Record<string, { sum: number; count: number }> = {};
    filtered.forEach((d) => {
      if (!clinicScores[d.clinica]) clinicScores[d.clinica] = { sum: 0, count: 0 };
      clinicScores[d.clinica].sum += d.scoreClinica;
      clinicScores[d.clinica].count++;
    });

    // Score by specialty (avg)
    const specScores: Record<string, { sum: number; count: number }> = {};
    filtered.forEach((d) => {
      if (!specScores[d.especialidade]) specScores[d.especialidade] = { sum: 0, count: 0 };
      specScores[d.especialidade].sum += d.scoreEspecialidade;
      specScores[d.especialidade].count++;
    });

    // Doctors not visited for 60+ days
    const docDays = filtered
      .map((d) => ({ ...d, daysSince: getDaysSince(d), bestCat: getBestCat(d) }))
      .filter((d) => d.daysSince >= 60)
      .sort((a, b) => b.daysSince - a.daysSince);

    return {
      total, visited, pending, visitedPct,
      catCounts,
      zeroCaptation, renovarMedicos, zeroCaptOnlyNonRenovar,
      highPotTotal, highPotVisited, highPotPending, highPotPct,
      lowPotTotal,
      goodCaptPct, goodCaptation,
      cityEntries, topCity, isConcentrated, highPotCityCount: cityEntries.length,
      focusData,
      topSpecCaptation,
      clinicCats, specCats,
      clinicScores, specScores,
      docDays,
    };
  }, [filtered, focusSpecialties]);

  const workedDays = Math.max(1, workedDaysCount);
  const visitedCount = Number.isFinite(stats.visited) ? stats.visited : 0;
  const dailyAvg = workedDays > 0 ? visitedCount / workedDays : 0;
  const dailyAvgDisplay = Number.isFinite(dailyAvg) ? dailyAvg.toFixed(1) : "0.0";
  const dailyAvgOk = dailyAvg >= 15;

  const pct = (n: number, d: number) => (d > 0 ? Math.round((n / d) * 100) : 0);

  const filtersActive =
    filterMarkets.length > 0 || filterSpecialties.length > 0 ||
    filterCities.length > 0 || filterClinics.length > 0 || minDaysSinceVisit > 0;

  return (
    <div className="space-y-5">
      {filtersActive && (
        <Badge variant="outline" className="text-xs text-muted-foreground">
          Filtros ativos — dados abaixo refletem a seleção atual
        </Badge>
      )}

      {/* 1. KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card>
          <CardContent className="pt-4 pb-3 px-4">
            <div className="flex items-center gap-2 mb-1">
              <Users className="h-4 w-4 text-primary" />
              <span className="text-xs text-muted-foreground">Total Base</span>
            </div>
            <p className="text-2xl font-bold text-foreground">{stats.total}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3 px-4">
            <div className="flex items-center gap-2 mb-1">
              <UserCheck className="h-4 w-4 text-accent" />
              <span className="text-xs text-muted-foreground">Visitados</span>
            </div>
            <p className="text-2xl font-bold text-foreground">{stats.visited}</p>
            <p className="text-[10px] text-muted-foreground">{stats.visitedPct}% do total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3 px-4">
            <div className="flex items-center gap-2 mb-1">
              <UserX className="h-4 w-4 text-destructive" />
              <span className="text-xs text-muted-foreground">Pendentes</span>
            </div>
            <p className="text-2xl font-bold text-foreground">{stats.pending}</p>
            <p className="text-[10px] text-muted-foreground">{pct(stats.pending, stats.total)}% do total</p>
          </CardContent>
        </Card>
        <Dialog open={calendarOpen} onOpenChange={setCalendarOpen}>
          <DialogTrigger asChild>
            <Card className="cursor-pointer hover:border-primary/50 transition-colors">
              <CardContent className="pt-4 pb-3 px-4">
                <div className="flex items-center gap-2 mb-1">
                  <Activity className="h-4 w-4 text-primary" />
                  <span className="text-xs text-muted-foreground">Média/dia</span>
                </div>
                <p className={`text-2xl font-bold ${dailyAvgOk ? "text-accent" : "text-destructive"}`}>
                  {dailyAvgDisplay}
                </p>
                <p className="text-[10px] text-muted-foreground">
                  {visitedCount} visitas ÷ {workedDays} dias
                </p>
                <p className="text-[10px] text-muted-foreground">
                  Meta: ≥ 15/dia {!dailyAvgOk && "⚠ Abaixo"}
                </p>
                <p className="text-[9px] text-primary mt-1">📅 Clique para ajustar dias</p>
              </CardContent>
            </Card>
          </DialogTrigger>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle className="text-sm">Dias Trabalhados no Ciclo</DialogTitle>
            </DialogHeader>
            <p className="text-xs text-muted-foreground mb-2">
              Marque apenas os dias efetivamente trabalhados. Desmarque reuniões, feriados e ausências. O dia atual (•) não é contabilizado pois ainda está em andamento.
            </p>
            <div className="grid grid-cols-7 gap-0.5 text-center text-[10px] mb-1">
              {WEEKDAY_NAMES.map((n) => (
                <span key={n} className="font-semibold text-muted-foreground py-1">{n}</span>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-0.5">
              {/* empty cells for first day offset */}
              {Array.from({ length: monthDays[0]?.date.getDay() || 0 }).map((_, i) => (
                <div key={`e${i}`} />
              ))}
              {monthDays.map((md) => {
                const day = md.date.getDate();
                const isFuture = md.date > today;
                const isToday = day === todayDate;
                const checked = workedDaysSet.has(day);
                return (
                  <div
                    key={day}
                    className={`flex flex-col items-center gap-0.5 rounded p-1 text-[10px] ${
                      md.isWeekend ? "bg-muted/50 text-muted-foreground" : ""
                    } ${isFuture ? "opacity-40" : ""} ${isToday ? "ring-1 ring-primary/50" : ""}`}
                  >
                    <span className="leading-none">{day}{isToday ? " •" : ""}</span>
                    <Checkbox
                      checked={checked}
                      onCheckedChange={() => toggleWorkedDay(day)}
                      disabled={isFuture || isToday}
                      className="h-3.5 w-3.5"
                    />
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between items-center mt-3 pt-2 border-t">
              <span className="text-xs text-muted-foreground">
                {workedDaysCount} dia(s) marcado(s)
              </span>
              <span className="text-xs font-semibold">
                Média: {(visitedCount / Math.max(1, workedDaysCount)).toFixed(1)}/dia
              </span>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* 4. Daily Average Warning */}
      {!dailyAvgOk && (
        <Card className="border-destructive/50">
          <CardContent className="pt-4 pb-3 px-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 text-destructive shrink-0" />
              <div>
                <p className="text-sm font-semibold text-destructive">Média diária abaixo da meta</p>
                <p className="text-xs text-muted-foreground">
                  {dailyAvgDisplay} médicos/dia ({visitedCount} visitas ÷ {workedDays} dias marcados no calendário). Meta ≥ 15. Ajuste os dias trabalhados clicando no card "Média/dia".
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 1. Doctors by Category */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-primary" /> Médicos por Categoria
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-5 gap-2">
            {[1, 2, 3, 4, 5].map((cat) => (
              <div key={cat} className="text-center rounded-lg border p-3">
                <div className={`inline-block w-3 h-3 rounded-full ${CAT_COLORS[cat]} mb-1`} />
                <p className={`text-lg font-bold ${CAT_TEXT[cat]}`}>{stats.catCounts[cat].total}</p>
                <p className="text-[10px] text-muted-foreground">C{cat}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 2. Non-audited / Zero captation */}
      <Card className={stats.renovarMedicos.length > 0 ? "border-destructive/50" : ""}>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-destructive" /> Médicos sem Captação
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-4">
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.zeroCaptation.length}</p>
              <p className="text-[10px] text-muted-foreground">Total com zero captações em todos os mercados</p>
            </div>
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="border rounded px-3 py-2 border-destructive/30">
              <p className="text-lg font-bold text-destructive">{stats.renovarMedicos.length}</p>
              <p className="text-[10px] text-muted-foreground max-w-[200px]">
                🔴 Renovar médico — cidade com mercado de captação ({CAPTATION_CITIES.join(", ")}), mas este médico tem zero
              </p>
            </div>
            <div className="border rounded px-3 py-2">
              <p className="text-lg font-bold text-muted-foreground">{stats.zeroCaptOnlyNonRenovar.length}</p>
              <p className="text-[10px] text-muted-foreground max-w-[200px]">
                Sem captação — cidade sem mercado ativo de captação
              </p>
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground border-t pt-2">
            Ordenação: médicos em cidades com mercado (Renovar) aparecem primeiro, ordenados por menor captação total. Secundários: cidades sem mercado, ordenados por cidade.
          </p>
          {/* List: renovar first, then secondary */}
          {(stats.renovarMedicos.length > 0 || stats.zeroCaptOnlyNonRenovar.length > 0) && (
            <div className="max-h-56 overflow-y-auto space-y-1">
              {stats.renovarMedicos.map((d, idx) => {
                const markets = filterMarkets.length > 0 ? filterMarkets : Object.keys(d.mercados);
                const totalCap = markets.reduce((s, m) => s + getTotalPrescriptions(d, m), 0);
                return (
                  <div key={d.crmPainel} className="flex items-center justify-between text-xs border border-destructive/30 rounded px-2 py-1.5 bg-destructive/5">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] text-muted-foreground font-mono w-4">#{idx + 1}</span>
                      <span className="font-medium">{d.medico}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] text-muted-foreground">Capt: {totalCap} · {d.cidade}</span>
                      <Badge variant="destructive" className="text-[9px] px-1.5 py-0">Renovar</Badge>
                    </div>
                  </div>
                );
              })}
              {stats.zeroCaptOnlyNonRenovar.length > 0 && (
                <p className="text-[9px] text-muted-foreground pt-2 pb-1 border-t">Cidades sem mercado de captação:</p>
              )}
              {stats.zeroCaptOnlyNonRenovar.map((d) => (
                <div key={d.crmPainel} className="flex items-center justify-between text-xs border rounded px-2 py-1">
                  <span className="font-medium">{d.medico}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] text-muted-foreground">{d.cidade} — sem mercado ativo</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* 3. Visit Progress */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Target className="h-4 w-4 text-primary" /> Progresso de Visitas no Ciclo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Overall */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-muted-foreground">Geral</span>
              <span className="font-semibold">{stats.visitedPct}%</span>
            </div>
            <Progress value={stats.visitedPct} className="h-2.5" />
          </div>
          {/* By category */}
          {[1, 2, 3, 4, 5].map((cat) => {
            const { total, visited } = stats.catCounts[cat];
            const p = pct(visited, total);
            return (
              <div key={cat}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <span className={`inline-block w-2 h-2 rounded-full ${CAT_COLORS[cat]}`} />
                    C{cat} ({visited}/{total})
                  </span>
                  <span className="font-semibold">{p}%</span>
                </div>
                <Progress value={p} className="h-2" />
              </div>
            );
          })}
          {/* Good captation */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-muted-foreground">Bom volume (C1-C3)</span>
              <span className="font-semibold">{stats.goodCaptPct}%</span>
            </div>
            <Progress value={stats.goodCaptPct} className="h-2.5" />
          </div>
        </CardContent>
      </Card>

      {/* 5. Speed vs Potential + 6. Panel Quality */}
      <div className="grid md:grid-cols-2 gap-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Zap className="h-4 w-4 text-primary" /> Velocidade vs Potencial
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 mb-3">
              <div>
                <p className="text-2xl font-bold text-foreground">{stats.highPotPending}</p>
                <p className="text-[10px] text-muted-foreground">Alto potencial pendentes</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-accent">{stats.highPotPct}%</p>
                <p className="text-[10px] text-muted-foreground">C1+C2 visitados</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              {stats.highPotPending === 0
                ? "✓ Todos os médicos de alto potencial foram visitados."
                : stats.highPotPending <= 3
                  ? `Apenas ${stats.highPotPending} médico(s) de alto potencial pendente(s). Priorize-os.`
                  : `⚠ ${stats.highPotPending} médicos C1-C2 aguardam visita. Foque neles para maximizar resultados.`
              }
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" /> Qualidade do Painel
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 mb-3">
              <div>
                <p className="text-2xl font-bold text-primary">{stats.highPotTotal}</p>
                <p className="text-[10px] text-muted-foreground">Alto potencial (C1+C2)</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-muted-foreground">{stats.lowPotTotal}</p>
                <p className="text-[10px] text-muted-foreground">Baixo potencial (C4+C5)</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              {stats.highPotTotal > stats.lowPotTotal
                ? "✓ Painel com boa proporção de médicos de alto potencial."
                : stats.highPotTotal === stats.lowPotTotal
                  ? "Equilíbrio entre alto e baixo potencial. Considere fortalecer a base C1-C2."
                  : "⚠ Mais médicos de baixo potencial do que alto. Revise a composição do painel."
              }
            </p>
          </CardContent>
        </Card>
      </div>

      {/* 7. Geographic Concentration */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <MapPin className="h-4 w-4 text-primary" /> Concentração Geográfica (Alto Potencial)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3 mb-3">
            {stats.isConcentrated ? (
              <CheckCircle2 className="h-5 w-5 text-accent shrink-0" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-yellow-500 shrink-0" />
            )}
            <p className="text-xs text-muted-foreground">
              {stats.isConcentrated
                ? `Concentrado: ${stats.topCity?.[1]} de ${stats.highPotTotal} médicos C1-C2 em ${stats.topCity?.[0]}.`
                : `Disperso: médicos C1-C2 distribuídos em ${stats.highPotCityCount} cidades.`
              }
            </p>
          </div>
          <div className="space-y-1.5">
            {stats.cityEntries.slice(0, 5).map(([city, count]) => (
              <div key={city}>
                <div className="flex justify-between text-xs mb-0.5">
                  <span className="text-muted-foreground">{city}</span>
                  <span className="font-semibold">{count}</span>
                </div>
                <Progress value={pct(count, stats.highPotTotal)} className="h-1.5" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Médicos sem visita há 60+ dias */}
      {stats.docDays.length > 0 && (
        <Card className="border-destructive/40">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              Médicos sem visita há 60+ dias
              <Badge variant="destructive" className="text-[10px] ml-auto">{stats.docDays.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-64 overflow-y-auto space-y-1">
              {stats.docDays.map((d) => (
                <div key={d.crmPainel} className="flex items-center justify-between text-xs border rounded px-2 py-1.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <Badge className={`${CAT_COLORS[d.bestCat]} text-white text-[9px] px-1.5 py-0 shrink-0`}>C{d.bestCat}</Badge>
                    <span className="font-medium truncate">{d.medico}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground shrink-0 ml-2">
                    <span className="text-[10px]">{d.especialidade}</span>
                    <span className="text-[10px]">·</span>
                    <span className="text-[10px]">{d.cidade}</span>
                    <span className="font-bold text-destructive text-[10px]">{d.daysSince}d</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* 9. Focus Specialties */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2 justify-between w-full">
            <span className="flex items-center gap-2">
              <Stethoscope className="h-4 w-4 text-primary" /> Especialidades Foco — Progresso
            </span>
            <Dialog open={focusPickerOpen} onOpenChange={setFocusPickerOpen}>
              <DialogTrigger asChild>
                <button className="text-[10px] text-primary hover:underline font-normal">⚙ Editar</button>
              </DialogTrigger>
              <DialogContent className="max-w-xs">
                <DialogHeader>
                  <DialogTitle className="text-sm">Selecionar Especialidades Foco</DialogTitle>
                </DialogHeader>
                <p className="text-[10px] text-muted-foreground mb-2">Marque as especialidades que deseja acompanhar. A seleção é permanente até você alterar.</p>
                <div className="max-h-60 overflow-y-auto space-y-1">
                  {allSpecialties.map((spec) => (
                    <label key={spec} className="flex items-center gap-2 text-xs py-1 px-2 rounded hover:bg-muted/50 cursor-pointer">
                      <Checkbox
                        checked={focusSpecialties.includes(spec)}
                        onCheckedChange={() => toggleFocusSpec(spec)}
                        className="h-3.5 w-3.5"
                      />
                      <span>{spec}</span>
                    </label>
                  ))}
                </div>
                <p className="text-[9px] text-muted-foreground mt-2 border-t pt-2">{focusSpecialties.length} selecionada(s)</p>
              </DialogContent>
            </Dialog>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {stats.focusData.map((f) => (
            <div key={f.name}>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">{f.name} ({f.visited}/{f.total})</span>
                <span className="font-semibold">{f.pct}%</span>
              </div>
              <Progress value={f.pct} className="h-2" />
            </div>
          ))}
          {stats.focusData.every((f) => f.total === 0) && (
            <p className="text-xs text-muted-foreground">Nenhum médico das especialidades foco no filtro atual.</p>
          )}
        </CardContent>
      </Card>

      {/* 8. Specialties with most captation */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" /> Especialidades com Maior Captação
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {stats.topSpecCaptation.map(([spec, cap]) => {
            const maxCap = stats.topSpecCaptation[0]?.[1] || 1;
            return (
              <div key={spec}>
                <div className="flex justify-between text-xs mb-0.5">
                  <span className="text-muted-foreground">{spec}</span>
                  <span className="font-semibold">{Math.round(cap as number)}</span>
                </div>
                <Progress value={pct(cap as number, maxCap as number)} className="h-1.5" />
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* 10. Clinic distribution with categories */}
      <div className="grid md:grid-cols-2 gap-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Building2 className="h-4 w-4 text-primary" /> Clínicas — Distribuição por Categoria
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {Object.entries(stats.clinicCats).sort((a, b) => {
                const aHigh = (a[1][1] || 0) + (a[1][2] || 0);
                const bHigh = (b[1][1] || 0) + (b[1][2] || 0);
                return bHigh - aHigh;
              }).map(([clinic, cats]) => (
                <div key={clinic} className="flex items-center justify-between text-xs border rounded px-2 py-1.5">
                  <span className="font-medium truncate max-w-[140px]">{clinic}</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((c) => (
                      cats[c] > 0 ? (
                        <span key={c} className={`${CAT_COLORS[c]} text-white rounded px-2 py-1 text-[10px] font-bold`}>
                          C{c}:{cats[c]}
                        </span>
                      ) : null
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Stethoscope className="h-4 w-4 text-primary" /> Especialidades — Distribuição por Categoria
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {Object.entries(stats.specCats).sort((a, b) => {
                const aHigh = (a[1][1] || 0) + (a[1][2] || 0);
                const bHigh = (b[1][1] || 0) + (b[1][2] || 0);
                return bHigh - aHigh;
              }).map(([spec, cats]) => (
                <div key={spec} className="flex items-center justify-between text-xs border rounded px-2 py-1.5">
                  <span className="font-medium truncate max-w-[140px]">{spec}</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((c) => (
                      cats[c] > 0 ? (
                        <span key={c} className={`${CAT_COLORS[c]} text-white rounded px-2 py-1 text-[10px] font-bold`}>
                          C{c}:{cats[c]}
                        </span>
                      ) : null
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

    </div>
  );
}
