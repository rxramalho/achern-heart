import { Doctor } from "@/types/doctor";

const specialties = ["Pneumologista", "Otorrino", "Clínico Geral", "Ortopedista", "Ginecologista", "Reumatologista", "Dermatologista", "Gastroenterologista"];
const clinics = ["Clínica São Lucas", "Hospital Santa Maria", "Centro Médico Vida", "Clínica Integrada", "Hospital Regional", "Clínica Saúde Total"];
const cities = ["São Paulo", "Campinas", "Ribeirão Preto", "Santos", "Sorocaba"];
const names = [
  "Dr. Carlos Silva", "Dra. Ana Oliveira", "Dr. Pedro Santos", "Dra. Maria Costa",
  "Dr. João Pereira", "Dra. Fernanda Lima", "Dr. Ricardo Almeida", "Dra. Juliana Ferreira",
  "Dr. Bruno Rodrigues", "Dra. Camila Martins", "Dr. Lucas Souza", "Dra. Patricia Mendes",
  "Dr. André Ribeiro", "Dra. Beatriz Gomes", "Dr. Marcos Barbosa", "Dra. Renata Dias",
  "Dr. Gustavo Carvalho", "Dra. Vanessa Moreira", "Dr. Felipe Araujo", "Dra. Larissa Nascimento",
  "Dr. Roberto Freitas", "Dra. Amanda Cardoso", "Dr. Thiago Correia", "Dra. Carolina Vieira",
  "Dr. Eduardo Teixeira", "Dra. Daniela Rocha", "Dr. Matheus Pinto", "Dra. Isabela Cruz",
  "Dr. Diego Monteiro", "Dra. Tatiana Lopes"
];

const PRODUCTS = [
  "ALENIA", "BUSONID NASAL", "BIXLYN", "ARTROLIVE",
  "MOTORE", "LEUCOGEN", "MONTELAIR", "OSTEOBAN",
  "COMBTOL", "ANDRUM", "BUSONID ORAL", "LAXIME",
  "NISULID", "CLILON", "LUBRIS", "LUTEAL"
];

const availabilities = ["2M", "2MT", "3M", "3T", "4MT", "5M", "6T", "2M 4T", "3MT 5M", "2M 3T 5MT", "2MT 3MT 4MT 5MT 6MT", "4M 6M", ""];

function randomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateMarkets(): Record<string, { semPrescricao: number; cat1: number; cat2: number; cat3: number; cat4: number; cat5: number }> {
  const markets: Record<string, any> = {};
  
  for (const product of PRODUCTS) {
    const hasActivity = Math.random() > 0.3;
    
    if (!hasActivity) {
      markets[product] = { semPrescricao: 1, cat1: 0, cat2: 0, cat3: 0, cat4: 0, cat5: 0 };
    } else {
      const cat = randomInt(1, 5);
      const value = cat === 1 ? randomInt(100, 500) : cat === 2 ? randomInt(50, 150) : cat === 3 ? randomInt(20, 80) : cat === 4 ? randomInt(5, 30) : randomInt(1, 10);
      
      markets[product] = {
        semPrescricao: 0,
        cat1: cat === 1 ? value : 0,
        cat2: cat === 2 ? value : 0,
        cat3: cat === 3 ? value : 0,
        cat4: cat === 4 ? value : 0,
        cat5: cat === 5 ? value : 0,
      };
    }
  }
  
  return markets;
}

export const mockDoctors: Doctor[] = names.map((name, i) => ({
  crmPainel: `${randomInt(10000, 99999)}`,
  ufCrm: "SP",
  checkVisitar: Math.random() > 0.5 ? "SIM" : "",
  falar: Math.random() > 0.3 ? "V" : "NV",
  visitadoCiclo: randomInt(1, 22),
  medico: name,
  cat: `CAT ${randomInt(1, 5)}`,
  deltaMedico: `${randomInt(-20, 50)}`,
  especialidade: specialties[i % specialties.length],
  clinica: clinics[i % clinics.length],
  scoreClinica: randomInt(1, 100),
  scoreEspecialidade: randomInt(1, 100),
  endereco: `Rua ${["das Flores", "São Paulo", "XV de Novembro", "Augusta", "Paulista"][i % 5]}, ${randomInt(100, 2000)}`,
  cidade: cities[i % cities.length],
  mercados: generateMarkets(),
  disponibilidade: availabilities[i % availabilities.length],
}));
