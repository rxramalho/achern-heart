/**
 * PAINEL MÉDICO - API Endpoint
 * 
 * Deploy como Web App:
 * 1. No Google Apps Script do spreadsheet médico
 * 2. Deploy > New deployment > Web app
 * 3. Execute as: Me, Who has access: Anyone
 * 4. Copie a URL e cole no dashboard Lovable
 * 
 * Spreadsheet ID: 1bGYVD0rFxmjwGnFgtQa-0dH5USO7SjiN7SgXUAcMGFA
 * Aba: gid=1321914827
 */

function doGet(e) {
  try {
    // Check if this is an update action (sent via GET to avoid CORS)
    if (e && e.parameter && e.parameter.action === "updateSchedule") {
      return handleUpdateSchedule(e.parameter);
    }

    var ss = SpreadsheetApp.openById("1bGYVD0rFxmjwGnFgtQa-0dH5USO7SjiN7SgXUAcMGFA");
    var sheet = ss.getSheets().filter(function(s) { return s.getSheetId() === 1321914827; })[0];
    
    if (!sheet) {
      return ContentService.createTextOutput(JSON.stringify({ error: "Aba não encontrada" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    
    if (lastRow < 4) {
      return ContentService.createTextOutput(JSON.stringify({ error: "Sem dados", doctors: [] }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // Linha 3 = cabeçalhos
    var headers = sheet.getRange(3, 1, 1, lastCol).getValues()[0];
    var data = sheet.getRange(4, 1, lastRow - 3, lastCol).getValues();

    // Produtos e suas posições (cada mercado = 6 colunas)
    var PRODUCTS = [
      "ALENIA", "BUSONID NASAL", "BIXLYN", "ARTROLIVE",
      "MOTORE", "LEUCOGEN", "MONTELAIR", "OSTEOBAN",
      "COMBTOL", "ANDRUM", "BUSONID ORAL", "LAXIME",
      "NISULID", "CLILON", "LUBRIS", "LUTEAL"
    ];

    var doctors = [];

    for (var i = 0; i < data.length; i++) {
      var row = data[i];
      
      // Pular linhas vazias
      if (!row[0] && !row[5]) continue;

      var doctor = {
        crmPainel: String(row[0] || ""),
        ufCrm: String(row[1] || ""),
        checkVisitar: String(row[2] || ""),
        falar: String(row[3] || ""),
        visitadoCiclo: String(row[4] || ""),
        medico: String(row[5] || ""),
        cat: String(row[6] || ""),
        deltaMedico: String(row[7] || ""),
        especialidade: String(row[8] || ""),
        clinica: String(row[9] || ""),
        scoreClinica: row[10] || 0,
        scoreEspecialidade: row[11] || 0,
        endereco: String(row[12] || ""),
        // col 13 (N) ignorada
        cidade: String(row[14] || ""),
        mercados: {},
        disponibilidade: String(row[lastCol > 111 ? 111 : lastCol - 1] || ""), // DH = col 112 (index 111)
        horarios: [] // DI:DR = cols 113-122 (indices 112-121)
      };

      // Read schedule from columns DI:DR (indices 112-121)
      var horarios = [];
      for (var h = 112; h < 122 && h < lastCol; h++) {
        var val = String(row[h] || "").trim().toUpperCase();
        horarios.push(val === "X" || val === "TRUE" || val === "1" || val === "SIM");
      }
      // Pad to 10 if sheet has fewer columns
      while (horarios.length < 10) horarios.push(false);
      doctor.horarios = horarios;

      // Mercados: colunas P(15) a DG(110), 6 colunas por mercado
      for (var m = 0; m < PRODUCTS.length; m++) {
        var startCol = 15 + (m * 6);
        if (startCol + 5 >= lastCol) break;

        doctor.mercados[PRODUCTS[m]] = {
          semPrescricao: row[startCol] || 0,
          cat1: row[startCol + 1] || 0,
          cat2: row[startCol + 2] || 0,
          cat3: row[startCol + 3] || 0,
          cat4: row[startCol + 4] || 0,
          cat5: row[startCol + 5] || 0
        };
      }

      doctors.push(doctor);
    }

    var result = {
      totalDoctors: doctors.length,
      products: PRODUCTS,
      lastUpdate: new Date().toISOString(),
      doctors: doctors
    };

    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (e) {
    return ContentService.createTextOutput(JSON.stringify({ error: e.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Handle schedule update from GET params (CORS-safe)
 */
function handleUpdateSchedule(params) {
  var crm = String(params.crm || "").trim();
  var horarios = JSON.parse(params.horarios || "[]");
  var clinica = params.clinica;

  if (!crm) {
    return ContentService.createTextOutput(JSON.stringify({ error: "CRM não fornecido" }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  if (!Array.isArray(horarios) || horarios.length !== 10) {
    return ContentService.createTextOutput(JSON.stringify({ error: "Horários inválidos" }))
      .setMimeType(ContentService.MimeType.JSON);
  }

  var ss = SpreadsheetApp.openById("1bGYVD0rFxmjwGnFgtQa-0dH5USO7SjiN7SgXUAcMGFA");
  var sheet = ss.getSheets().filter(function(s) { return s.getSheetId() === 1321914827; })[0];

  if (!sheet) {
    return ContentService.createTextOutput(JSON.stringify({ error: "Aba não encontrada" }))
      .setMimeType(ContentService.MimeType.JSON);
  }

  var lastRow = sheet.getLastRow();
  var crmCol = sheet.getRange(4, 1, lastRow - 3, 1).getValues();
  var targetRow = -1;

  for (var i = 0; i < crmCol.length; i++) {
    if (String(crmCol[i][0]).trim() === crm) {
      targetRow = i + 4;
      break;
    }
  }

  if (targetRow < 0) {
    return ContentService.createTextOutput(JSON.stringify({ error: "Médico não encontrado: " + crm }))
      .setMimeType(ContentService.MimeType.JSON);
  }

  // Write to columns DI:DR (columns 113-122, 1-indexed)
  var values = horarios.map(function(v) { return v ? "X" : ""; });
  sheet.getRange(targetRow, 113, 1, 10).setValues([values]);

  // Update column DH (112) with disponibilidade string
  var dayCode = ["2", "3", "4", "5", "6"];
  var parts = [];
  for (var d = 0; d < 5; d++) {
    var m = horarios[d * 2];
    var t = horarios[d * 2 + 1];
    if (m && t) parts.push(dayCode[d] + "MT");
    else if (m) parts.push(dayCode[d] + "M");
    else if (t) parts.push(dayCode[d] + "T");
  }
  sheet.getRange(targetRow, 112).setValue(parts.join(", "));

  // Update clinic name in column J (10) if provided
  if (clinica !== undefined && clinica !== null && clinica !== "") {
    sheet.getRange(targetRow, 10).setValue(String(clinica));
  }

  return ContentService.createTextOutput(JSON.stringify({ success: true, row: targetRow }))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * POST endpoint — updates doctor schedule (kept for backwards compat)
 */
function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents);
    return handleUpdateSchedule(body);
  } catch (e) {
    return ContentService.createTextOutput(JSON.stringify({ error: e.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
