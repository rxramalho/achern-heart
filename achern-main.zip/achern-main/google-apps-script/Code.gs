/**
 * MENU PHARMALINK - Disponível no Desktop
 */
function onOpen() {
  try {
    SpreadsheetApp.getUi()
      .createMenu("📦 Pharmalink")
      .addItem("Atualizar FP (Manual)", "gerarJSONDescontosFP")
      .addItem("Atualizar SFP (Manual)", "gerarJSONDescontosSFP")
      .addSeparator()
      .addItem("Modo PDV", "modoPDV")
      .addItem("Modo Analítico", "modoAnalitico")
      .addItem("Limpar Quantidades", "limparQuantidade")
      .addSeparator()
      .addItem("Ativar Agendamento Automático", "criarGatilhoAutomatico")
      .addItem("Desativar Agendamento Automático", "removerGatilhoAutomatico")
      .addToUi();
  } catch (e) {
    console.error("Erro ao criar menu: " + e.message);
  }
}

/**
 * GATILHO AUTOMÁTICO - Executado pelo trigger a cada hora
 * Seg-Sex, 7h às 19h → roda gerarJSONDescontosFP em modo automático (sem UI)
 */
function executarGatilhoFrequente() {
  try {
    var agora = new Date();
    var diaSemana = agora.getDay(); // 0=Dom, 1=Seg ... 5=Sex, 6=Sab
    var hora = agora.getHours();

    // Seg(1) a Sex(5), das 7h às 18h59
    if (diaSemana >= 1 && diaSemana <= 5 && hora >= 7 && hora < 19) {
      gerarJSONDescontosFP(true); // true = modo automático, sem alertas UI
    }
  } catch (e) {
    console.error("Erro no gatilho automático: " + e.message);
  }
}

/**
 * CRIAR GATILHO AUTOMÁTICO
 * Instala um trigger baseado em tempo que roda a cada 1 hora.
 * Remove triggers antigos antes de criar um novo para evitar duplicatas.
 */
function criarGatilhoAutomatico() {
  try {
    // Remove triggers existentes da mesma função
    removerGatilhoAutomatico_(false);

    ScriptApp.newTrigger("executarGatilhoFrequente")
      .timeBased()
      .everyHours(1)
      .create();

    SpreadsheetApp.getUi().alert(
      "✅ Agendamento ativado!\n\n" +
      "A função de atualização FP será executada automaticamente a cada hora,\n" +
      "de segunda a sexta, das 7h às 19h."
    );
  } catch (e) {
    console.error("Erro ao criar gatilho: " + e.message);
    SpreadsheetApp.getUi().alert("Erro ao criar agendamento: " + e.message);
  }
}

/**
 * REMOVER GATILHO AUTOMÁTICO (via menu)
 */
function removerGatilhoAutomatico() {
  removerGatilhoAutomatico_(true);
}

/**
 * REMOVER GATILHO (interno)
 */
function removerGatilhoAutomatico_(mostrarUI) {
  try {
    var triggers = ScriptApp.getProjectTriggers();
    var removidos = 0;

    for (var i = 0; i < triggers.length; i++) {
      if (triggers[i].getHandlerFunction() === "executarGatilhoFrequente") {
        ScriptApp.deleteTrigger(triggers[i]);
        removidos++;
      }
    }

    if (mostrarUI) {
      if (removidos > 0) {
        SpreadsheetApp.getUi().alert("✅ Agendamento automático desativado. (" + removidos + " trigger(s) removido(s))");
      } else {
        SpreadsheetApp.getUi().alert("ℹ️ Nenhum agendamento automático estava ativo.");
      }
    }
  } catch (e) {
    console.error("Erro ao remover gatilho: " + e.message);
    if (mostrarUI) SpreadsheetApp.getUi().alert("Erro ao remover agendamento: " + e.message);
  }
}

/**
 * CAPTURA FAIXAS ANTIGAS DE DADOS_SITE
 */
function capturarFaixasAntigas_(sheetDados) {
  var mapa = {};

  try {
    var lr = sheetDados.getLastRow();
    if (lr < 2) return mapa;

    var dados = sheetDados.getRange(2, 1, lr - 1, 6).getValues();

    for (var j = 0; j < dados.length; j++) {
      var ean = limparEan_(dados[j][0]);
      if (!ean) continue;

      var faixas = [];
      for (var f = 1; f <= 5; f++) {
        var val = dados[j][f];

        if (val === null || val === undefined || val === 0 || val === "") {
          faixas.push("");
          continue;
        }

        if (typeof val === "number") {
          faixas.push("");
          continue;
        }

        var str = String(val).trim();

        if (str.indexOf(" a ") !== -1 && str.indexOf(" - ") !== -1 && str.indexOf("%") !== -1) {
          faixas.push(str);
        } else {
          faixas.push("");
        }
      }

      mapa[ean] = faixas;
    }
  } catch (e) {
    console.error("Erro ao capturar faixas antigas: " + e.message);
  }

  return mapa;
}

/**
 * ATUALIZAÇÃO FARMÁCIA POPULAR
 */
function gerarJSONDescontosFP(isAutomated) {
  if (isAutomated === undefined) isAutomated = false;

  var ss, sheetDados, abaControle;

  try {
    ss = SpreadsheetApp.getActiveSpreadsheet();
    sheetDados = ss.getSheetByName("DADOS_SITE");
    abaControle = ss.getSheetByName("CONTROLE");
  } catch (e) {
    console.error("Erro ao acessar planilha: " + e.message);
    if (!isAutomated) SpreadsheetApp.getUi().alert("Erro ao acessar planilha: " + e.message);
    return;
  }

  if (!sheetDados) {
    if (!isAutomated) SpreadsheetApp.getUi().alert("Aba DADOS_SITE não encontrada.");
    return;
  }
  if (!abaControle) {
    if (!isAutomated) SpreadsheetApp.getUi().alert("Aba CONTROLE não encontrada.");
    return;
  }

  var mapaFaixasAntigas = capturarFaixasAntigas_(sheetDados);

  var TOKEN_URL = "https://apimkt01.pharmalinkonline.com.br/Ache/token";
  var API_URL = "https://apimkt01.pharmalinkonline.com.br/Ache/api/produtos/obterMixProdutos";
  var USUARIO = "rafael.ramalho@ache.com.br";
  var SENHA = "AcheCrescer@6959";

  var payload = {
    "CNPJ": "07.316.504/0001-64",
    "CondicaoComercialBaseId": 20047999,
    "IdPrazoPagamento": 2,
    "IdsDistribuidores": [{ "IdDistribuidor": 36, "Ordem": 0 }],
    "PdvId": 17992,
    "TipoDePedido": 4,
    "UtilizaComboOferta": true,
    "Origem": "WEBClient"
  };

  try {
    var token = obterToken_(TOKEN_URL, USUARIO, SENHA);
    if (!token) throw new Error("Token de autenticação vazio ou inválido.");

    var produtos = chamarAPI_(API_URL, token, payload);
    if (!produtos || !Array.isArray(produtos)) throw new Error("Resposta da API inválida ou sem produtos.");

    var resultado = processarProdutosAPI_(produtos);
    var mapaStringsAPI = resultado.mapaStringsAPI;
    var mapaFaixasNovas = resultado.mapaFaixasNovas;

    atualizarTabelaDados_(sheetDados, mapaStringsAPI);

    processarLog_(ss, abaControle, mapaFaixasNovas, mapaFaixasAntigas, "FP");

    atualizarDataControle_(abaControle);

    if (!isAutomated) SpreadsheetApp.getUi().alert("Faixas FP atualizadas com sucesso!");
  } catch (e) {
    console.error("Erro FP: " + e.message);
    if (!isAutomated) {
      try {
        SpreadsheetApp.getUi().alert("Erro ao atualizar FP:\n" + e.message);
      } catch (uiErr) {}
    }
  }
}

/**
 * SFP - COM LOG
 */
function gerarJSONDescontosSFP() {
  var ss, sheetDados, abaControle;

  try {
    ss = SpreadsheetApp.getActiveSpreadsheet();
    sheetDados = ss.getSheetByName("DADOS_SITE");
    abaControle = ss.getSheetByName("CONTROLE");
  } catch (e) {
    console.error("Erro ao acessar planilha: " + e.message);
    SpreadsheetApp.getUi().alert("Erro ao acessar planilha: " + e.message);
    return;
  }

  if (!sheetDados) {
    SpreadsheetApp.getUi().alert("Aba DADOS_SITE não encontrada.");
    return;
  }
  if (!abaControle) {
    SpreadsheetApp.getUi().alert("Aba CONTROLE não encontrada.");
    return;
  }

  var mapaFaixasAntigas = capturarFaixasAntigas_(sheetDados);

  var TOKEN_URL = "https://apimkt01.pharmalinkonline.com.br/Ache/token";
  var API_URL = "https://apimkt01.pharmalinkonline.com.br/Ache/api/produtos/obterMixProdutos";
  var USUARIO = "rafael.ramalho@ache.com.br";
  var SENHA = "AcheCrescer@6959";

  var payload = {
    "CNPJ": "09.471.839/0001-82",
    "CondicaoComercialBaseId": 20047999,
    "IdPrazoPagamento": 2,
    "IdsDistribuidores": [{ "IdDistribuidor": 36, "Ordem": 0 }],
    "PdvId": 34709,
    "TipoDePedido": 4,
    "UtilizaComboOferta": true,
    "Origem": "WEBClient"
  };

  try {
    var token = obterToken_(TOKEN_URL, USUARIO, SENHA);
    if (!token) throw new Error("Token de autenticação vazio ou inválido.");

    var produtos = chamarAPI_(API_URL, token, payload);
    if (!produtos || !Array.isArray(produtos)) throw new Error("Resposta da API inválida ou sem produtos.");

    var resultado = processarProdutosAPI_(produtos);
    var mapaStringsAPI = resultado.mapaStringsAPI;
    var mapaFaixasNovas = resultado.mapaFaixasNovas;

    atualizarTabelaDados_(sheetDados, mapaStringsAPI);

    processarLog_(ss, abaControle, mapaFaixasNovas, mapaFaixasAntigas, "SFP");

    atualizarDataControle_(abaControle);

    SpreadsheetApp.getUi().alert("Faixas SFP atualizadas com sucesso!");
  } catch (e) {
    console.error("Erro SFP: " + e.message);
    try {
      SpreadsheetApp.getUi().alert("Erro ao atualizar SFP:\n" + e.message);
    } catch (uiErr) {}
  }
}

/**
 * PROCESSA PRODUTOS DA API
 */
function processarProdutosAPI_(produtos) {
  var mapaStringsAPI = {};
  var mapaFaixasNovas = {};

  for (var p = 0; p < produtos.length; p++) {
    var produto = produtos[p];

    var ean = limparEan_(produto.Ean);
    if (!ean) continue;

    var faixasStrings = [];
    var faixasFixas = ["", "", "", "", ""];

    if (produto.FaixasDesconto && Array.isArray(produto.FaixasDesconto)) {
      for (var i = 0; i < produto.FaixasDesconto.length; i++) {
        var f = produto.FaixasDesconto[i];

        try {
          var soma =
            (f.CondicaoComercial && f.CondicaoComercial.PercentualDescontoBase ? f.CondicaoComercial.PercentualDescontoBase : 0) +
            (f.CondicaoComercial && f.CondicaoComercial.PercentualDescontoNegociado ? f.CondicaoComercial.PercentualDescontoNegociado : 0);

          var d = normalizarParaDecimal_(soma);

          var qMin = f.QuantidadeMinima || 0;
          var qMax = f.QuantidadeMaxima || 0;

          var faixa = qMin + " a " + qMax + " - " + (d * 100).toFixed(0) + "%";

          faixasStrings.push(faixa);
          if (i < 5) faixasFixas[i] = faixa;
        } catch (fErr) {
          console.error("Erro ao processar faixa do EAN " + ean + ": " + fErr.message);
        }
      }
    }

    mapaStringsAPI[ean] = faixasStrings;
    mapaFaixasNovas[ean] = faixasFixas;
  }

  return {
    mapaStringsAPI: mapaStringsAPI,
    mapaFaixasNovas: mapaFaixasNovas
  };
}

/**
 * PROCESSA LOG
 */
function processarLog_(ss, abaControle, mapaNovas, mapaAntigas, origem) {
  try {
    var dadosControle = abaControle.getDataRange().getValues();

    var mapaControle = {};
    for (var i = 1; i < dadosControle.length; i++) {
      var ean = limparEan_(dadosControle[i][0]);
      if (!ean) continue;

      mapaControle[ean] = {
        linha: dadosControle[i][1] || "",
        nome: dadosControle[i][2] || ""
      };
    }

    var registros = [];

    for (var ean2 in mapaAntigas) {
      if (!mapaAntigas.hasOwnProperty(ean2)) continue;
      if (!mapaNovas.hasOwnProperty(ean2)) continue;

      var antigas = mapaAntigas[ean2] || ["", "", "", "", ""];
      var novas = mapaNovas[ean2] || ["", "", "", "", ""];

      var antigasNorm = [];
      var novasNorm = [];
      for (var k = 0; k < 5; k++) {
        antigasNorm.push(String(antigas[k] || "").trim());
        novasNorm.push(String(novas[k] || "").trim());
      }

      if (JSON.stringify(antigasNorm) !== JSON.stringify(novasNorm)) {
        var dados = mapaControle[ean2] || {};

        registros.push([
          new Date(),
          ean2,
          dados.nome || "Desconhecido",
          dados.linha || "N/A",
          antigasNorm[0], antigasNorm[1], antigasNorm[2], antigasNorm[3], antigasNorm[4],
          novasNorm[0], novasNorm[1], novasNorm[2], novasNorm[3], novasNorm[4]
        ]);
      }
    }

    gravarAbaLog_(ss, registros, origem);

    if (registros.length > 0) {
      console.log(origem + ": " + registros.length + " alterações registradas no LOG.");
    } else {
      console.log(origem + ": Nenhuma alteração detectada (LOG recriado apenas com cabeçalho).");
    }
  } catch (e) {
    console.error("Erro ao processar log: " + e.message);
  }
}

/**
 * GRAVA LOG (RECRIA SEMPRE)
 */
function gravarAbaLog_(ss, registros, origem) {
  try {
    var abaLog = ss.getSheetByName("LOG");

    if (abaLog) {
      abaLog.clear();
      abaLog.clearFormats();
    } else {
      abaLog = ss.insertSheet("LOG");
    }

    var dataAtual = Utilities.formatDate(new Date(), "GMT-3", "dd/MM/yyyy HH:mm:ss");

    // Linha 1: Info de atualização
    var infoAtualizacao = "Última atualização: " + dataAtual + " | Origem: " + (origem || "N/A") + " | Alterações: " + (registros ? registros.length : 0);
    abaLog.getRange(1, 1).setValue(infoAtualizacao);
    abaLog.getRange(1, 1).setFontWeight("bold").setBackground("#4285f4").setFontColor("#ffffff");
    abaLog.getRange(1, 1, 1, 14).merge();

    // Linha 2: Cabeçalho
    var cabecalho = [
      "DATA/HORA", "EAN", "PRODUTO", "LINHA",
      "Fx Ant 1", "Fx Ant 2", "Fx Ant 3", "Fx Ant 4", "Fx Ant 5",
      "Fx Nv 1", "Fx Nv 2", "Fx Nv 3", "Fx Nv 4", "Fx Nv 5"
    ];

    abaLog.getRange(2, 1, 1, 14).setValues([cabecalho]);
    abaLog.getRange(2, 1, 1, 14).setFontWeight("bold").setBackground("#fbbc04");
    abaLog.setFrozenRows(2);

    if (!registros || registros.length === 0) return;

    abaLog.getRange(3, 2, registros.length, 1).setNumberFormat("@");
    abaLog.getRange(3, 1, registros.length, 14).setValues(registros);
  } catch (e) {
    console.error("Erro ao gravar log: " + e.message);
  }
}

/**
 * NORMALIZA %
 */
function normalizarParaDecimal_(valor) {
  if (valor === null || valor === undefined || valor === "") return 0;

  var num = 0;

  if (typeof valor === 'number') {
    num = valor;
  } else {
    var str = String(valor).replace("%", "").replace(",", ".").trim();
    num = parseFloat(str);
  }

  if (isNaN(num)) return 0;

  return (num >= 1) ? num / 100 : num;
}

/**
 * OBTER TOKEN
 */
function obterToken_(url, user, pass) {
  var payload =
    "grant_type=password&username=" +
    encodeURIComponent(user) +
    "&password=" +
    encodeURIComponent(pass);

  var r = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/x-www-form-urlencoded",
    payload: payload,
    muteHttpExceptions: true
  });

  var code = r.getResponseCode();
  if (code !== 200) {
    throw new Error("Erro ao obter token (HTTP " + code + "): " + r.getContentText());
  }

  var json = JSON.parse(r.getContentText());
  if (!json.access_token) {
    throw new Error("Token não encontrado na resposta da API.");
  }

  return json.access_token;
}

/**
 * CHAMAR API
 */
function chamarAPI_(url, token, payload) {
  var r = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    headers: { Authorization: "Bearer " + token },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });

  var code = r.getResponseCode();
  if (code !== 200) {
    throw new Error("Erro na API de produtos (HTTP " + code + "): " + r.getContentText());
  }

  var json = JSON.parse(r.getContentText());
  if (!json.Produtos || !json.Produtos.Skus) {
    throw new Error("Resposta da API sem campo Produtos.Skus.");
  }

  return json.Produtos.Skus;
}

/**
 * ATUALIZAR TABELA DADOS_SITE
 */
function atualizarTabelaDados_(sheet, mapa) {
  try {
    var lr = sheet.getLastRow();
    if (lr < 2) return;

    var range = sheet.getRange(2, 1, lr - 1, 6);
    var dados = range.getValues();

    for (var i = 0; i < dados.length; i++) {
      var e = limparEan_(dados[i][0]);

      if (mapa[e]) {
        for (var f = 0; f < 5; f++) {
          dados[i][f + 1] = mapa[e][f] || "";
        }
      }
    }

    range.setValues(dados);
  } catch (e) {
    console.error("Erro ao atualizar DADOS_SITE: " + e.message);
    throw e;
  }
}

/**
 * ATUALIZAR DATA NO CONTROLE
 */
function atualizarDataControle_(aba) {
  try {
    aba.getRange("A2")
      .setValue(
        Utilities.formatDate(new Date(), "GMT-3", "dd/MM - HH:mm")
      );
  } catch (e) {
    console.error("Erro ao atualizar data controle: " + e.message);
  }
}

/**
 * LIMPAR EAN
 */
function limparEan_(v) {
  if (!v) return "";

  return String(v)
    .replace(/\.0$/, "")
    .replace(/\D/g, "")
    .trim();
}

/**
 * MODO PDV
 */
function modoPDV() {
  try {
    var s = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("CONTROLE");

    if (!s) {
      SpreadsheetApp.getUi().alert("Aba CONTROLE não encontrada.");
      return;
    }

    s.showColumns(1, 19);
    s.hideColumn(s.getRange("H1"));
    s.hideColumn(s.getRange("Q1"));
  } catch (e) {
    console.error("Erro modo PDV: " + e.message);
    SpreadsheetApp.getUi().alert("Erro: " + e.message);
  }
}

/**
 * MODO ANALÍTICO
 */
function modoAnalitico() {
  try {
    var s = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();

    s.showColumns(1, 19);

    var vis = [1, 2, 3, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19];

    for (var c = 1; c <= 19; c++) {
      if (vis.indexOf(c) === -1) {
        s.hideColumn(s.getRange(1, c));
      }
    }
  } catch (e) {
    console.error("Erro modo analítico: " + e.message);
    SpreadsheetApp.getUi().alert("Erro: " + e.message);
  }
}

/**
 * LIMPAR QUANTIDADE
 */
function limparQuantidade() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var s = ss.getSheetByName("CONTROLE");

    if (!s) {
      SpreadsheetApp.getUi().alert("Aba CONTROLE não encontrada.");
      return;
    }

    s.getRange("O4:O620").clearContent();
  } catch (e) {
    console.error("Erro ao limpar quantidades: " + e.message);
    SpreadsheetApp.getUi().alert("Erro: " + e.message);
  }
}
